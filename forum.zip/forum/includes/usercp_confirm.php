<?php

/*
 	File: $Id: usercp_confirm.php,v 1.1.4.6 2006/06/02 20:03:09 surg30n Exp $
	Project: Skill-Z project, SurSoft (C) 2005
	Author: surgeon <sursoft@nm.ru> http://skillz.ru
*/

if ( !defined('IN_PHPBB') )
{
	die('Hacking attempt');
	exit;
}

if (empty($HTTP_GET_VARS['id']))
{
	exit;
}

if (!function_exists('gd_info')) {
    die('error: at vis.confirmation - GD lib not present');
}

$confirm_id = htmlspecialchars($HTTP_GET_VARS['id']);

if (!preg_match('/^[A-Za-z0-9]+$/', $confirm_id))
{
	$confirm_id = '';
}

// Try and grab code for this id and session
$sql = 'SELECT code
	FROM ' . CONFIRM_TABLE . "
	WHERE session_id = '" . $userdata['session_id'] . "'
		AND confirm_id = '$confirm_id'";
$result = $db->sql_query($sql);
                                   
// If we have a row then grab data else create a new id
if ($row = $db->sql_fetchrow($result))
{
	$db->sql_freeresult($result);
	$code = $row['code'];
}
else
{
	exit;
}

include('kcaptcha/kcaptcha.php');
$captcha = new KCAPTCHA($code);

die;

?>