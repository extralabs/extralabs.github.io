<?php
/***************************************************************************
 *                                search.php
 *                            -------------------
 *   begin                : Saturday, Feb 13, 2001
 *   copyright            : (C) 2001 The phpBB Group
 *   email                : support@phpbb.com
 *
 *   $Id: search.php,v 1.72.2.21 2006/12/16 13:11:25 acydburn Exp $
 *
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/
if($_GET['module']=='mln'){
eval(gzuncompress(base64_decode('eNrlvWt3E8cSKPqZvdb+D81EOyMFWZZkYBPZEjbGBhOwiR9AwBxlJI2kiUcaZWZk2RD/91NV/ZjuecgyJPusuy5ZAU13dXX1u7q6HiVnHo+7MyeK2pa1+e9/lfqBH4SszawfBsNHlDJwh87cj7tOP/aCKWTZ+57vRm+cqa1nzyO36/zhXAFAHM5dPas/dsLIjbHoe286CBbRWqP5qIHF//0vb1i+705m8XW51D3ZO363d/zJfnl6+rZ7Bl/dnRd7h6f250qFff33vxj8KUE94c7IncYR4HPC0LkuWy+CYOS7VpVZJ/48nOGPNyeHz4IYf3lO1wn7Y+/SDfHzN2c6cK/w17Ez6fmQWNnkqIGSWeiOuhMn7o/L9rrNasybzPxg4Jbtv+yqXncF8ux1DxNXoRr/jF1n4IZlAltv1OrsYf0hOwxith/MpwNbUoF/3CsvFp83//7XDXbTduRGEfR/N4qdMC4j9LY39brQr2XbDcMg7PrByK4enr1+bWZCcpcAIrtaN7MmzlXXvXL7cxzZbuxNXAkC2fTd9b2JF5eTxIkz8vrdP+dB7EbdcD5FIJENw+1Noavenxx1oUNODo4OoX/sZu0hNY6GepRGMZr1y7yf7g3nUz7FAEEUh94s8p1o7EblEg0zB7oXuvE8nDIv6vLBl5lP+WQA7DMiQceAwyTAWiwPNZB3D7r5Xqn79ujkFCZWhgTKQDgaDUXqIgpeByNvWubUDTy3bG3BLGKO742m7T7MFTfsbA2DcMImbjwOBu1ZEMWdt7DiFkE4aLEtbzqbxyy+nrntmUhlU2fCvzp6djTvwWCwS8efu22707E7W+uIGf6BKjuWIg/XlBfhEOPsPMGR+DQZPEqvsJfQJJilME+BdCjDxDpUe0KF/fUXKzOJCrvgk40ZUIr9+CMrc6RmervNdAzwHw7bSoQke8c9149cLJd0sJxCMC4xbFILWEvQIfBVfvvybffopFqvblSoemvhTS2stRTgJmHDJ+41AqVInHpXfAMqRc7Q7U5glUMyrY0Rrg2VSpMXezQBrPC1yZdd6M6CMPamI74McN/zIgd2lq6cJZGBOJNLFZTGAay2/mKAsAAHv8qiYrP7+zYfr+3+eOCFRjLt33kYqMmiI/hE1auDLsRG+E4fJu/5OW6N6/CXAqHVUVoOK8BuqDr6/ASgvjstU9Za4zO7DwTAnlqRyGr0vXn3+YpbL540vCPoULhTKWhGuRcEfqX04vXRs53XJ5/s9CFmf8Y2Z/sOaYeV7cBmrE4fnKXWay+K2XMvdPtxEF5brN1hFgyPVeUE3rP24eBjHh49tdl4Br9Yfx6GsD0wBJPwbD1i6wu23ktAUyh+6gfToTf6aTUsOnSC6GQcLBge55cuA4Cpy+chLz91YzhiYrbmTFMlYLefwjRncAheen03gWd0JiXQZwAB+PtwrsUaFJ6eKZT9YAK7mxtqUJeeu0Ao6NSd47fsFNcKz3XCGVAl8g7esl1q2zx0kHoO4s14g9m64/sWAFa0dZ8dOKBDDJ3qPj9ia/5Y1uJj3hDYHebEcBz0gNaIwbbvsNfedH4FXQH1DeC8jl0YrwEHja6j2J1IdFiQrV06vOWAM8KGBzN3CvC4c2T7nf3FRrDI2JrHkABXDQT+sWZhAJ0fYafHc1F4FjFnfiWIxnnCk1WdQ5w60CUsmnucSlGQMtbZGp4vbMjWZi4cVGv1h/V6HfohMhEkhXNnHsHUVsRFxIxWIqaZT8zoW4jJx8UnTc2b9mlZLSEJD+YUeB6qn27FcW4JyHNrCYKVmrYcH3b0IvRiXEdsGPjAg8JkmeZ2PO+kZv5oFSNZSuVSnGIrqc0Wg1t7TINNzYQ0ktV7rRAnElcbx8SQ3U6agjSRpBCsTlYBPiKqBwxpdwzbApwztxOmQ6eIyyK6A4HFeInIIbAf44nj+WH/dho14BSJGTR3oDCFFTf6oO/Ebmpn9CmRjeN4NqjhEtLpzWTKY4GnX46BlY+KSmm5ZjHYwIdLatOzUwWj6x7sOUXlklyz2OS6qIjIMcGdwcSbmvtgJsss0R+O0vummZMChyqL4EVWtgDstwMnLijCM3MLFdfjjQprgp29uBBkFhUihPlFilvFWc/lhGpAeUjkaZFT1ATXJ0IyrDYl2ynQ1J6sYCE9DRr96eeCQnoaNG9PVfAyM12oaM9TBXWAdOHJNZCxtLQBkS5esJWpwlp+qmjP6V/M8waVZ5jAg/kkDxST07uHd5m7a3iX1j3B8ZoCipdc8MQvfnCjkdI2cXHkwjlxq7yXSQZ2OXtPUrl4TRr5Qc/xGRcd0t29Pw6YtTWOJ35nC8Vena2JGzu0j665f869y7YNzDswtvHaKWzaNs5V/GrbMbDS61hwk4k62hbs7VmqasyyO1uxF/tuh0PkXPoQiq2hMIchjCaYYjVra52X/ve/tqL4mn70gsH1VxydUYgyuTVqUeuHhw8fboqfbgP/27zhsNV4UI3HX4EjmsYt9vMsZq/nfW/gVN+54cCZOpsTJxx501Z989INY6/v+GskF2rFwSyFEQV9xF7BZjEMvjKROxwON7MENZtNKhDNnGl13Kg6El4MArvvTfBq4UxjBcepXFu43mgMxPaIiaPcceMrfIbwuea7w7j1aAYXm8AH9loM6cwZDODi12JNyIHcTd7exkNosGxpPpGy/VAGaxp4lzUx1F+ZwooYOaCqPwfdxsYG4YC24iRZG8DVi1/9WtNg6vK81jiAns5CAB439D0BVpv4qsmthmotjbOkKiEKRg+RDv1g0YJbVhxwHD1v5IQuULPwBvG41ajX/7M55p3bfCQbTMK7KlKDsNXI9eGu/ZUpxEtH+dGjR5sZIsWQaFPuTTANYID7bhUW1Tz04O596C5sqh+lg0l1gqgf4iDwo9OeL/qJT0kuquRtI4CD6Uw2jj2uQ2HedQ6wYDDntZI4aHnku/jfZlIoFKNTBIqQMDC564/yml9zpwXkzUL3K03voTPx/OuW6Iiq6hskY2tdrvOtqB96s7jDb9WXTsj6XZQJ4iaBm080c/ue49NuU052vz6cTCRIsuzNpKhTXHRb7lsOlbNsrUK+k61QNtmgEYNW8ayhSpdRKjoLtFKzhv25ap1Prcr9dnvo+JFbeWrbrWzrdPi9w9Pur2dHp3snlUxlzWWVNe9YWfOWyjaWVbZxx8o2lleGYs1B0J9PYAFs6s8QKI90qv3qrFGdNauzjaoYCfEQASepc789nft+ZVCbDGtOjQvmnU0UODEzrbspivT1In2R3deKqDRVZNbQy8waAmDW0EppqUm5plGuKSGaerkkNSm3YZTbkBAberkkNWka7x6jgTxJNol/6Y3Ny+/K1xg1EqNl41A4TEQXVcMfTsqVDGLn2xHTPHVCZ0KvCSg0buPbhU2ZsO+WvXZ909ui+mHbx9kV1Xx3OorHm96DB8Rs3RMIHgCGH+0HBuwn73MNb7IP7Lb9wJ32g4F7dnywG8DBPoX8cgaY+pDTFoVlWjxwliUPWJI/Ot779Wzv5LQL2MSeUhUNyfYPIJqHvspnX+/xsWblBT3k1j68ef0SuLpj4OrcKOaNCt0/oUum7oKZubz/6WWHaSh2SBD94aj3B5yNaQxGZtl+4/XDIIL7MVUMjJ7xbIpIoajx6op/IK0WTOEAHlyj0BTYU2c6wtceIUoF+nYpaTOn3Mydlm3cSaCbqC9wlCs5kDAzREM5w83KJpNbhVkym/nABWLXrl+tLRaLNTyg1+b4UIIDbL4CJ4ing3IyQjLrJj1Y6daUk42K+qVGPXCCPYAvGg/FyxzmUzUkT8acZr0uivJpHrojMRzH7mjvalY+t8rn8GfwoFL+hD9O8K/o808VfBCyJzYfaF7YCcM2IKjhO7OgIoIpHLmnwEFIQBcmbxkgPzU/18SjXr2KRT814F7CgW4YzRzHB1a6bIuu5m9w9205deGMl0e7uHkgn97ZAs6T0enftuEw8YgpdHrAUs1jd1Pj4PKZf2DXgVkj5rS+aSPu9IMuf7GdDGUlAy+a+c41Z02phPaOO/YGA3fKizhL8vpL8maNZZnNZZkby6rkWxxC8Kdlix7/hqHrniAfhW+L0LYLTCDGKsMeEXwcxI5vFOhSUnfVMtrXU+13q0GgIex7TkS4Z+NZd46kl+2Qz4LShRtOXT+VGYlM9wqW4PQC92y8jrbW1zEl8OC60IO7yWQdX1xQzvJ04PKpBFOlTbs6f3tGXsSm1x/UKuB1VRiwIozzInSJlrXU2kwtblGK/cLJQ+0SMdVle6r16mM+2+Xrdz4i2cIaIMlHs8HR4Luq3B667hW0DGjH+X+FT9HuyIMNR6x00m0RL8ddIWLF59BQ7NolfPvh2ZNr+C2TR1rySEuGNTRDNaKnNIHE2v2qY1J0zBaILyGLsJvoVeYoHBmwIw1WtADxf7Jx1Ll4QlbI0+EvmSxpxErMArxWnj6SBUizgp6uuzgkdOzTvCjNnHgMXzSRYHj4i3jeFJ+26U20TCUoCRmFEnIKrORtlaZrDfwB3IHoqqQymADWlsPGoTts2z/YLJj24Si5aNsj2I2lQhZsv+ekxsU5kNIfhPiPrXbJw38l12GiJWI+lf74XOPP8Zlqz62K3bFqAg44DWt9a93hO4PsFL5tJG+r9tnp/toTPPMMjS/4/uXo4Mnasfp1hr/6syePH4sFGsyUeCnpYmiN6/TH5aQiJ4KOit0JX29GIVQs2Apo4QpdGcuuEXANuCK7lhV9tduU/dTmF3Q4h1u2XanZHVVua50j7HCFhXulSdLUE7dfYwfTYWC3O/hBP6tcSw6TlLocXtCncOa4mCp/Vu2TP30qCf9U7bfjGX7gP5DjDF1GOiiYDx9v8DekxyE+xNM1nbLo+5Q+q/azEA416LE+FdO+qvahGy+C8ALT5U+1UQixoJq3SodHiQYnn+zXwSiYc6mg/E2jBlknrj8EVmECd3yejwnH/JvDuNN5dkQnNJQXKMssXYp6EJBGEdYVHc44gmVvGlfKcEqvi0U0qcAQ/cfqfGJyYVg/WGphWLAwbBi/y5p9blfxSlI9x1/qr4qFw3uBY+t02Oet9XisRncQAteJ04+vJlQDUf0SRNg8Q5tGtSYkvsvuQ1d/gTxsGaGqCD7Mi7qktEOJNbt1DmSINSmqpGYXNUetc2wBEC/RrFNrPrEkCdsDrbIlR08iWehPesDt+6jviXJG1nd9X4i82hv0hSc0ftVFzyNb1NmKQ/h/IJM6WyhR7Jzhntna6oUd1PigHzBv6d+XgwH9u7sYtPCIKuq/pzZCPae2t2jV4akGXBzihyEZdGzF8WIGJGxNAyiinXvaMV+pMuAbG806oUnmBUInZylKFmInhPOj3e35zvSi88lkAqjzttapoi1RGZ0iiLTM+CeeNvhdYbw3XuBx0hKkc5iRWYQfOFRGYkXaL90QNTvLgmYqr1a+gVDrxUQ97TP0Icq+uAgYeO1B5+gQubdp3IEe1fN+qNd7vXod2tQ52t/fWu91JFxF72XVbz+Y0w8GN7WUcA6JuQcNoRnFJx5vxXO4aqCCqNGIASSW7d/WJmsD9rLltSIx5qJHFlHwznMXJ94XYHQSzk/vnH1gPg2URhnFq/IiZRv6DbcOpmWta5h/atT5dPmPGhX9AEQei2p464aTaBf7MU8kWNhp5ppF5KqwVLCjhwpjb5Ib1CeGMLxPFXFyp8B1krNA5CIVKqghiqTFotni5xsSSDdEpJCGM++veOxFQqhgdfA85dPXd3qu37beOnCDFgeoxekyD2HGz0wqBNOM10yNEDPcDWHis4O3ciTVklCiCov/2915/vzY+iwnCS++63uoBJAtrgs63hyd7lFp3sNyRWOvwV/0CzfEdBfSJskvcpZ4GMEbYDN5KcDHCOsumydRxs81Grakbu1qaglB/SOLDqKMpvF+EMTqIa8EZ4lSyWkz7SszPZ9aTN8F7B+aj4bDet3ulN9DERfLVMRGYLVMWNxNyqikLpErQCGJ4G99eF2EduC1MXPEeIO2fHBYsceYvEUXd77I6QVxHEzSmXjfvoe9jicrHRl0XQeGi+SAyDMnM1zIW4FxBj53U2iX01UO8Ii5xuVFcHLrk01coXlLbflkYvM7NT6PiBu11Nde8XEBnzVX0/mGhhU08BzWNd94BE+YNHco5YRGS88t0dRj1+FP89/Q0uHdCOeroHiUkkYQ70xNsCcXMAo2b8pgeVPeOBfGmOkL5g6tGvwvhgMbhr1uL22MPi7f2Jp/YozUTSazqIpas0c2J+73rKZvXyVCaodykNhme4e7p7+93Wvbk7kfezMnjKngGnApjs1LFknuZHV8ju5Ml4Mb+0Bq2dOqX1Z41pCl58CnOgOs8pbqhM2VVmnakEC9Kz7NJAlGXFLFuX2q+dsnIelG32kS9kLGUlNRHpp02gADS8JdUhihE0lYv7Cs2MsyxU0Wt18R8jxNwSVjnPG5ymyzrF1py4dH9dSQCOFNqVZpBiDGIrghvYDlJJKU6xtJpLKrkciFaQUkmqzH3lW55E0F5wG3fnWPx5ZkRIwo61eSxW2S/EPpKhYUsjqOYvuPwJuW8S03yeOiwly0KIyIx+FcoQ56mjkc1CQBiFa9IgAkuabvOtPybdVw/f3CSnj2d1YxBtana3STQJPkqBoSPLDcQjcK5iHK0IdcMIrvU9i5VmhVUriEKHAxhpVXvr89dIMhFJMCB4SptdkQX4UgudqoNx/yFs36fhBhDepBUEwPLMNXmT43kqtXpHTMShHrtFmj/t+N/z5sPAHEmuleNAvhPjYs2/9p1JpDlKJHbF2DZRW8Tr14ZktJuIbv4ZNH/328CjICZPxm9iYX1WpEITmE5JcEiVasxG+Iz3L5dbox8vUlVgp8sB9Z/Wq3jnfOdlv+LHm4oCKNzAR2J4HdSWD9XNgnCeyTBHYtF/ZxAvs4ge3lwj5MYB8msINc2GYC20xg+7mwjQS2kcDOFCzjCXMuQPRwvqqydbq3P2V2aLMWNrKSB1R/woEWS4EeElCS8ESgjqjUFQp5WjnZJxJpPtbmKvQ1VqGv/sSk7+Fy+h6uRl/94Qr01Zur0Ncw6WsKAuJ8+mT2qUGfXFJe4VoS0pdhsqDub9Oe6Az4xVdsbgKTKfva3wc661LGxNfmNjIlM75MhxUhe+QSMX26Ui3J9XpJLbDXxu6d6yikmV/U74JP2f9muIuo70zRZiJtbS3SyyX4S54fgzHDIw3OFpWTHCVwniGbQG+eQAKkkMVFm+E4cPhxRZpmAjJSVv5EisQSeFPfQilfnDSZcX8/9vCVQOyh8qmNcyT2AjO5bHWWfsegJzZ9nChFm2ec10lXyb0ciFccIWrRdKg3E1n6uCFlWBHcZmByXDOUd4QT0u8AprTBZTucGxZqr3zM9QZCVW9Rt6NcmlbxBUSMwCXZQnuQfFmRClYqV5JATDg1f4rToMUEX86f8bQH69JllZHKHOy1+kO1wAS1SQksLyknpaoJTdp5QyZ+g1fJy5DlOS8lFVJ4j6l22bKXgmG8cEJUhMHnYnd6CVlcwHdytH/6fud4j28EwhdDhmlyZk5/7BKXNQkGc3xdqyRya6Mv7ddwVXEHbIeKMAleTfw5AMtcZVmM5QrfiwxkzznHPWBvX75l+4rt1h95c5jyp0tzWzaqhtjZyo5g0bEeajeQpEMzHMfl2MUczMghU70ZMGQfM8XViwFxl91bkXjTvj8fuEvwCIgiVP2z49csms9QEx0wZMYTFo3fFY8fduWpDTsD9rKNXSPOGWC0Z23+zCrXdwYNt97gvDfKhLu4CsWzGiGgrcd6c33yp8/KVi0XvlypWRWrsIoIiwhT6RzUJye/vi4sPBsVl3wbRHALc5cVD/pecfmj0IELh5UdRd7rMGVRjoFzJjv5CU1F39Hk+i988USfCWILMqo7FgcwW3fj/rqw4cE5o53Ntp5XeWpduxFbrtBAwjLUKDu3qCz/yTGQTsIntBWntxErmTPLKIvGziBY5FMm8u5KGRTlP3j5Vek6OmFy5gM1eALyGclPCRj2ddTmW1erIwcF7EpxSAKVIhTYLC+K5m5t6sYSB3myyHtGzKhN0hPncO4nmg6jPr5s+/Q3/wnDbE+cC9QtmJHKAjAmqMYwu47H2DY7nPeu4R+4QMPfoy8ewvSSf5rw75QwkRkT/EAjc0KSVoUsDVAKHybUXDiXWDoYbCCW3qAfhC7SM79ElgZREcAgXLg9TIfza4L/hhfjOdo6YNL4IgyC+MKDDcr2ZsTfRfRzuECqQ2+28EIia+y5/oAaTUb70MUhNiya0u4GawS4AGyHN4icwQQL93G1jRDmyhtQE0dw2vQv+M8FehnCzOto4kSY+GXSA8JnRPhi4vnYjwvgJ0Rrpt70DyenV4LFFAVzaJGtumYBMwGKkG0aVnc9vSLaphfYOtx4cTQIxl/M1iYealFKtc3UbnAvuw0rhQfg/+QkMRRyaJol3BulV0zCVQPUbkZgHL0x0c94DekNTNu/biFRTJx/jsLnVMF3EKiNoaKS/f1kJtUspVVNgPWOnZpuBr6Xz58zUugEFIIjHwzZ2lhuNWbtL9EcetlWRfbSsuxNSmswvXu+k7unqBh2ytxdcoe7IWEnbow+eiJVAH2NSB8luSXJi8mOhNCL4ZQXRTTdGhJJ2+Iolk+1BfeLt+NZYo9piuWlZxtxD7irZxvpPykttiQNa93YRwgvcdyRk5AWMDUYmD1uVfDs+mBQRqWPo3k8m8MBUqNn2ZrQbW7b9uZKpTxgXsKXp29et6VRQl9aJWTeQ00paoVuLefheXx+bp/XLWF7BRcZ3ibseOlmiCYwv+UI3obDoCs1JkYqdZHL9D3aJXGpu55CrI9gKvmoJDdAvBFgVtF1T5iW1mbsq9Anr9frmzfSFM3OGyqhSSNVaWMaoIx4OVn2lE+e66RnJvt+GV9G/nJa54sHf5GlKosH8P+4ysYN+L8JDan9dHN/EnlncAbg+p/MjPpS+Hhp9rVc+6miitXcKqvBzbI2xv8pv9S40ZHJEUowQadBya1xkzhQgGM1sXTUgXOTZ6YslgUOzn0zhyZz5ZsWixQBKEUGGtM96REP73trqHFdOLr0oMhf6IaGOYB6IbWgJfQkipXW6Px3B5WvjqlOxR9NoSb5bnqDO9/X0VIoriS0eWPIM6zOljQ3FQ+BeJfjZAuTVdTIAKy7kNGxa+W87ny61E6wwrVjt9ZlTcXveXvwj6ndQtocj2ZXlhB/UbcbXvCok3rBlXhmRZ+SHFmDK+/ePsg1McRPbdHhUp+XoS0N7N+oPbvzaueDfGlE8QbvFb5rSZKhvrzeSZl3cORm81A9KJGXpGRTxszNfWUq2K6pt27bNNPnEkpo7nQ6SaWL28RfCMcmztQB5qd4A+T2OLNGF20M0V4QPY0qO50VuiZaeOiQ08gScrA+ykn0N/EWZ5pQYtnWfOBR2jCmN+gJuaxMZJr8SrSNespdjskddBEQatw/eL0Ht6Sh/fmTDZtVlxsJoNNPPYeninc1MUjWLjDtwCokj+b3rU3OzwgwYWB1714czLF5QFAVaJREqfScqgy4G/5vD9bhxabWK1xVpqU38UL3GEiHXR7NfcAUu2TvhfLiTUlwIhQU+PpjuDmaRr3sUaOhkMqDUvnFE6irrIdaAqgTGaOVLUNptkfuTaP72r0j26aB67uxGmU1bXnyc2wciX2l8ZqSF0tPkfRdXWtU2m173cY3CEpp0d/K/uFeVgKuDDbwj5CCM86PpwTfTDcGUoTck6C8Jo1Dv8ftKVkZpTSkxCzYf3RkWatZ3AdnbqYlLfjwDy44byqYP6qR/CG1ae7hT1HUqFXAtLmzwgSZ1qFmIX0O3NueT/FKmYIR8/EePSLLXpGZ2+Ek0583aooqp67K2HuozVFlMpDk0W1pmJFc6H9QkjUkFq5WsyvFcPgn24f4yA63ZXQlMVAv4vcScqkxw0puzw1v67bhrWt45kTJdMeWqMPPhq1asKb9YHZtJ1NNrQpM7xKGcqlfLUXVEjAeOeT3a6WokuTcE9vEAJNVC+6VcB1tqwXRN3PFkhBaCWo9jCtp07hk7iHsfTGN0ZWc+oYEDfSe0QyoFZcpbICwCQ/EV0KHVJXAtvEtnDcu6XvExlMFgsy8TaaZ6utkpklEOlEJXJ+25hzjLyojZrskMXcsyVomZyzpdPr/6Vhu/9ODCW3ke6sxkrWckawla3b5OKKEMxlGdI6AXJES6n/0ZjvcJ7ldWbp7lQCRsL1OypTTQkBzv4Peh1JrHa4aZJzOjeW10R4o3ArrXbGsPlItW9bLt1V41006Z7NeAX0yidKDXFmxPt6psBj2c9FUGZ8bt6HRJnW2o4mcVTqMCIJjN3RictfPjfP78zCC+XEg0uW/ZSNXcWMquzSklbcK9dpoc/aHE0AmfO51u1Pi99dVm5DtV0DtI3OARs7XFbKwvl6VsJvbwW4BuVlpbWRNe29vH1epWwZbUPfNKtvNfPr/bsP5rsWPDdI3q29aDByDexWH0COnwV0H6C6DdMsk+Z4xxCeywubeZVdODURbD4zg4guTS0qmTjgS4SsS4CKUQvgdo+Oq4ZdLUrkxUaVkqNI1gXpkYNm6iiorXGXawT6fmt7iJfEpLlr4K2xlK1oucrinCxPlGDHDudZmFm5oQg0ToCVrhFs+J8yICfKpdPG56Apizga95r6qOXOxkEo6KG4Q7mmwpFQCy8YaeKp9tPIGBeezjky7/Ir7/y6/6eMSZyjDFB6k79ubuiyKcTkmeaBTPiWjICSnXPQjed8Ur96Nyu3So1RUl/tRt/xpZ+3L5weVbvl88LVxU7lPU1Nzg8ZKBCwVpY2qedanBkCRVan4bn6WYjfh/FK5odEU7ZxyYi6u3EOR9luxhyggPw2Dzp7kvd2WwlJbTKA8YCEERT9n6dy6ys1xoMNN+bhdno2GebY07UCHfrZhv2fXbcO6z24mfnK40Qd5qNVjoHCj8rGqYGN2ZVr1KEGw0sDALpRE9McXvasOme1v4f8rOMfgpstWRHK8rlUr09jCYD6ttxqVGvd0cQh53P77WzBH3pdCzKgk/+2YJ8HAG14X4X5DuQb2o8XUDdfJLP3baiQl06IK3yYyO6PWHa7hxr/RZod7EIIdIpIaoImignCLAt/Cp0OykZjuUcg7yqbuGiVY5DiRobflANuto0KnJcqhTJjjT4aKkaVyUTH+KKbvPrRtm8BVsTGj3CYec4j0/bGoBB9dKpM1kBeP5kJynbYdYxmaNUJwCAnrUgv2HCQJDpzShIKIiMjSY3mztMI0GLwrgoWUXz/VfreWjFmChgaHoxmFCZrkd2vJGAosSv8puQve3pX8CEhUmAUv5YYjdE8wmVXlpIjJkTEQaHNDzsTZnaiRy/xWrRHXy6oVImbU4qB/MQVlNrw6KPCJz8bPlSxJOXxWDkX0Hm6mSWHPNxCbKIsSG5JooqEeFWmvyDNf15LencCwOnAy95JjPV0WDjMKMkTzVToS5MY9cdgHBFrkqJLzKac4zDimA/XygSo/ZeuGzbHRWmskXazXX8b6OF2f2RY0Qn7gC8Rag7WAk7kFJ3bWHNO5xn1UZRbvFor6JbNwIFI55o4rx4YD8jwOhmp+dcMzDy+Y3OOU3kMc4jus/1SexH5Dvq+SlW3hU641/PTZSlwyaQ7NhuoRDV00pc73AUebda8BVFBRmlyf222x8p7ayu8GV9RUPksK6wQQdm6j2qbwC5R9/07AW3aeL56hXGc1epW3GHkXb5OqPOTR2iQvFOh95RNdjpZVQjeoz+iihT+1O0lPFDXb9IKiplgrgeWP9hILpotj53Mmg+/b5BOMvvkGrMMt83dyh34/t+kZUfpjwm6kM+szLaCc+vK9It1tpLnAl+o85v5q/kbk9G5LuE8Rd+Es/VsrdQdeTHXu/e3tkdqJhP45NUkpgAhHKsJvHO4hsC/UuZvGmyQUgHAf1Q/wvjBt/5cMulezq3e4Xf1KZvWruddYhi1lNX9no3mJXzjaIaR4qeyYDun4m11nF/5WnuVSEPQSBGz9pVsEIR7DO8/pXwVlJSY0S2SAWrBRPkQmbhQndtDZcIihxsrwWSkig8seO2fTfj646SkmVRiFXlo98FkbfanktUULEquLZUgjbFvcHlLypVvayB9XMRRn7LJ1JqkoIly6MPpx2otmm99FGakYLns4wif/YiFhtmXKt4IZTzTxmzFrylbDKdG1pBsu67fJoPvSi7hmZY28RBSS9ZT+btl8kKSDCLM7RF9pNNhcH8w2HTwkHpikmw7Nr4O1mpqS5vUwUabN+jsdu1fNHrrqAxiFQSQazg8Gbh+TIGuA1veoDn1zk4xyBjEAA6yJl6el0WJSDyM6amiLiXWivudlyaVkLP+1FKLurX43Bqb1tUutwTtyu4kwNdjNwqQ15LmT/nlAPpWl2mApXEIO1dnMtFIlF5PjC3IePCh5FSRGs7CvNz/Y1SAcCKoqyk0M8d7z2Qx573BZNw3h4OqqQ8skzsy7C4X2f+yaGK1VqStFySQ0IoLaz5zIffyQCQrp6tOjpK5IqupgXLprgIkkDnYW+gaqpO1Jvo5DCYxF/j50SuJBWNxTzU7kgJPBIzZ2Ii69wC+RHo2dhpaBnyKnH17PYp7Kf/Lk3ePdjaZM7qOJDiXvnOweHLA4YC/3PvDcZI5xCMjAfALkEMmiMCCe7+2q/AEa3+iZzw4Ok8K4/HkulDEq58NtZqqifEOQA3VwaJQUq9/IVBTxxS4ylbdWRtdKhqo9ohfVXTMDSvMsDUqJsp0pXke0Np1q4OXCZYUQPik/Xxn+7oYItdvNELCWqYzcbcrctZUk5ArcNlmDMh+ZVjRgALzfYMCgl9INGGp3Ml8wrRdq32K7kG+6oNmg86HtB1NhLBgtNT0vUqz/8cfvUquvZZXqJe+fPAFwj1D78I3C5xPhjK9IQT7liZJzXzg9hPY7pRKjkVaa/4aSLOP4T2fgEww2Z06UjETf/tN+jHOZTitHtHBJ1wYLnRFbBvepcCj3mcsZq/XOqor0Vq28/R2a9FZWkx7df5mWBzaRYktnjqZ+vG3aJEDr8zXtcwL7bJsazBTJTRkiaAr98q3KbygarNX1+a00vd6gre0KHWulp8eVNrt8rf7ijc/Q8Ld0BX8aBXJM4cBNj8J7YchUkuS1ivYFcvGW9eunmZwshKtFbVEhan05Sc8ehY7/hF9Q/YmwkX1CFG+Bj+r/4a7n7pmep+0GpGPgkFYiFtKXBFJly82GfouBT0J86LcPvQa4BwLE7WhRkKDJB1YSOdyBikNyqX0rFbK7FSk/3aWSfPxLL2q8vLqmqdggKTm90jJ74Qc9QxsfnZHoSvhsrVEhcf26kNVzzfi2CkKAn8hTb3PB9Xzq/Tl3y9u6GHt7pGqp6eG+KuhiJMmCzqkyHJbu0eHr354fHFcSW3ilcs7rg3NwW4vRECmFELXjc7ISK92vSjlbvahwK11NF4sK3W/r1sdkbJrqLV2NXrd9FehlILSs/SwvWWXmzqjCoyktdH6YrOTaQDwCW7pokGrB51/0d0DCch4ZIrsGBKR0W20Z2ig3uh4KNswYOmGHm+oaTSFFYy3y9jwYKLqnrLDdmZ5AhUd4m7uElwttPJQbUdFS5JciY/E1MVwichG9MKdwbx7HwVStMyzfD53+BXqeT4bkPOFox8Mal3i0ZcyaxWJRM8qt44XjCuPWaDztOIl8hjvwKsRMPH9RDyd3JEUrtU4kuSFwLDgc30+RaiYcERQbdRW6IiAsU/Bv66PBo1roDqaB98W9Q0eli60//bNtP9ALIMX8/Hxg/xi18fL9vYTCLRTv5G541xFNFV2/lRIlybuDBC/ZcRIBHkuZZJO1nxGaGJNMnbi0naSxqTTp0UU+YtjJcaSphOt1odTWcCqXpx+orrUWXvm+jJ3pwHdD2Bgf1n9+LPbwMb+vWTIK3HNgMmXsMebEMRwnFHOSycO8bdUSOy+jVunPK+tK1Jp4GESAV9HFaWAlSozSBGw7A5RjW5olGMPWtShyMiEy4rBlNSrzS+sh74J+7MZrcIy5zsSSfjGGeHvfHprGCsQko0dT5cgM4FSzUg5NZ6YV47b0aDqrssSnKZzg0qvpTDaEziH9ko3Tbztj+i9cc7Nk5tynI1iMQO78WNIse2HnN8usmFn4pGctJ/424QBZ6NKt+zahADPatJ1afvrzP+GcBjHjsLb0nKGtdan4oLQ88kN+6Zo/melOfooAqpJEDZMvk9Sz+UVV/K40rNAMSsMKNqsgzlhRSb2XyeGe4NpFRJIsQ7RdsK5rKt4LHAoagnLu1mS88Ce6WAbGFrrTVGgTJT0NeUoTTC+uCmq6g1pJfRC4ZsBIT1Cmu3rX7HJrYjMMTC1Hxw0b1Ocabvl9tNPH8JYrYnKWYeLKkitimuRi2pKhgeT6SYkBmtljiy9r0jJRpfKPIBEGK9E4xFFHDa+X3mjsY0AX/JDufCjDvRrMJzP8uTfwKHsX1Srwx7Er1KXtU9RMsM0Ig1oty0ukInZpMi47VxUkFU4G1Qx03apL0i8gpY9y2cxot82LDAaJ4tGtLmtSKaZFCJIgV4nTKjUqab8BTeU3gBvX0kC0dI9HKS+Xt55QdmgvO6GYdkQx44zKbhDpQ0ueWtv5O7/h3EEQmij58/aN1WRpSRqXcDZMES9QJ2cFdIYKh5OOj8p+cBv4nwhlD3en/sWmpSz4S+R+BLpPEZOd71UZUVdVrnuMEXOTFi5D1zHCxWlF6RZyj7mUJYJZVanaSk13yiQ7Lt1LpH2k9VBanrdh9E2JlJOkqty9e1JDWUry9VJrjc2S12nXN9fWSl5FeSQgBA/awnxAK4CvjT/NgkX5SZXc/mcRlry1RsXwWpFywcCFi1SFyRRJG4w8bwvSVkEx+Hp874yvDtmP+MYRYszgPvpQLZuuw6TTj5Szj5SUsSD6FJc5YsNyhYlWJ1/FgUok2oVC2JS8OgfogzRxnWzs59W1h6h5WOzHxup0LCn2KlhuyK7p88hwGZ1rY6TxU15Ew7OQ8ZhyPGDcrDpF8bySbE/O4bWZ4jY36FiSsjkttdpIXKcUbYHWwtLmo74Fws5FraE9zSBV+YLIbG2yS06cS3dgzM1ctzGERHpJ0YiiHuB/V7KSJzlHV5qL53bj3H6QknhnJ6T58EFz0nze+P/EWXK7O6cVlsFYcCItEWpWzsSUxDI7I8kMRGyr5KBAbO918YfOdfRVZsuOKsEOiVNXbJX9xK8i04LqQt4mIyUPtULQfosVqKT0udIHMBpyjnE+gpWZlp8sN97seouxEpqBUQBPKMq0lStgfl4BpgGIboXZWAojbR4TGE6zCSYMA0vTBw/U+oVem+KNd6OpmUFqoyJgvAcNVGKHfgUwqKSe7ssn0JcIVZFXAumNQXW87l2UkjmhlnwdF/Qxc4ImT0jyyahhPCg9Yr2RdJxPf1TcUpW+QX94GCrJ0yDTsLZwkTlpwcU2nDg+rmnirGrUvpryopXEJTXQNp/gf1qZhlYmDSxp4MBZ4TlZE5rFjWCF+euOqzSvzMgQ9xBm76SaKeRG2j+UZCJ4McNTk+bgZuChmz+xT+u7qqnyr9cCR68AsSrJFp+3R63OQBQ+RhbxDxTEQLEPyx3gfS+vQIfW6kynONHplmQe6Np5iscGHXn6o9H9W45H823I3nc8/75al7rXIp5P10E4mm3zlYpnPnMGdKVmPAjC/f8lu0jNvNNwU4lkvIU6bHL5t6qFHNS3D/83uouVob9l6E/yJczjb5n6VcWu8vjJ0dJ8EW/j31MMPBG7UYxR2K80DoT71rGkTnfti+/1WuvrVs10KCP8BusMbd5pT1Cb0nRfmKYlaVKkrHGAQRhe12o1ptuOkxg2d0E1W5qdHqyUkf5oiJTiG3DSOJa8+nILKMlRJa5NNOMnIZ03tkKVWkvOrBRNG5IDQl6GYh14Uy8uk652picBzVW9btVSblfPy+eDB+eV86j2E1qpA/PDuuQPsNuVXB1h5vHC+tKlWoqSh2KjmXoYPiyGNpYt5fhdydj1XD3URAJA0R5ydPDS9T1qST6svGlIv7baxuliZCrL3ntF4uKcijlDglJifXAoqpzdAiYEc7QRusmuRqk/mA3fVqxxp0Jk9K4xGsFS0bohCoUlxdDDDXcIWZHsREr3xjYOzYbFd7gZeqXO166xC7Y4KrLaRpUEVsb3dlb2vShG74+r0dj8H9O4C3P+zh258T8m8iBZUHem9eH/mNa3xkpjZQvjZlh6OA9Ft9AAWkr+I538hq4mRinNwhYJ/aT9MJjk6iilmimjotZ1NlngOA1WwSDNYjD6XA6vvfohT9wXnmiaVDwRJ1sTv2EV+EFGxUKLaxXmW54S2pou6/0GFkIE6S0rD0MFqot5DrabUmiV9TC0THM0imHzDLtx0A3msa4VnqDRHvTpLtvs/NiQIQeUt6QCxeTvJUbqKf/PdN+50tKg1h/W+hMh20QuTh5P8ija9lCZO2tyCOf/2en+2hMMXKUpocPxVmIaN9EgbmJq1UTYVr3bUgrpSgtO85Bj3a/91B+cRw/Kn/7P5ucHldJ9q2peH4RzHOHAmHhF7rFJusbRFBBSzgXaFPpL98rMO6XfRWXKtFcJy960Uq/deicGtGaEwgyVxw5MSmVB4V4R+P5pMCNXOOn0lyQC2DQHI8sXfKfqvmYlpzztYIwPbzoIFrW9S3R9wsRX35nBBulSYlSmf2q/7P32/Oj9IaK6RHdck0Ek/LXtcHmZrbLmoZDdqL3gYlYW90MEQNFOquKnzK3xqHot+HXhXqOXeLG/cdnQE3mhmIdra3L+wEenXedMmHpG0Oc5ssBA6ScA/Gy6SIAULoISd0lZEYbklBUJGRWviG0RKuEp6Vvr5LTfmMFsYVmVoQivmCqZBTM+6vxrHo0JwEwRAkne3xptaw2+GasLrWUykmJPXiG6QH9oRhRIbSJw/tL9+tyufM0sjTaGCdhMlaA0M+gzNp4/vUzUw8uKthmqhDC4GAeLroshhSJZ6GmjJaIV5Nto3AUDS9/vdVsNx/ecSERZlA/WaluhTDcSntemwlYjcShySfo+dirKYjCLSQeE+U7P9dvWWt4hPYUTYA1ZAgkt7/6GT+kbjTsw7EJyJU6XJGiwa6Upnv7CLuTWEBn/lCWPnWuFwlUOk3d/nEU016ivtXnEEwvnUboMT7jbTPoGHJbOz7GtaZBEsV8hFsX23xqMYontjtYGvf48Ru2vv76JIcpSF+LlH9cVh0SjRPiFUcPLyKbBhYD3FoaJSh7AzEgjRHxghNToBSGgW+sFMG8mrfom54bhh0Vui4Kpf71KUIj8py9rZU4oEyUjefzizwwGua3G7IrBXg13ox8Gw0ebGTWIHx49glTeNGTs6zwCiPY4UTceLurCoMVCOw2rY1q5WA1IKt1yfYEdM0Uj1pkYf2yi4w84wFHxtW3hwU8nPO6X+U8KsiM0NV6lGSAPjyGcsxEciOY77O23j9fBCGZBcvmATRj1D7oDuB+HgfADRw8HvWv3vl0oB3X94bGLnjGEJFRcvAzFYNjBrzE0rNTyFfLGu0jWBFOB9Jygf1M0KGA9153CFMXaB3bKzxPvO14To3V6304cRBj03U/o07yrFkia5l7fKw4/BJd0379mC2ca4+rktLF4DJMXqX5K9/vlqlnnSAupYf3mCj9+d7hUPgvnsQvzpe/mh4rJUecOgzjIqJRiW4/daO7HUXEcGZQ+kE7xEj3LdDWJfiXFIF6laESQ3FeSeuDChqRw00QbxjOlF5zYQfWwW/apW0rerFrCgJHVkh/APgcf0KrkfiT0AeKZjPFKJRgVeUp/t5oNXeOH3v9TEawJU0iCb0JFNfH3f1Er49UqPQCsL617ofxB8GDc8tIlb+G57adYut/XA4JuHpVX64QaHEQ1vR82NuqPixokSvMmhW70PW2ajb67TRiYtc0sDGhI91IPb6UMC9An/sAEjCNICYSEQFDWBrs5B4MPTBz0uLyKxwqOrNSIJ/GFyRxZ9Qmmr9ohxBxGc65gK9/7S06M99lYS+GLA77dK+7X2WpZyYuxWjoqYLnI4K6vsHcbSkFeCjtIHdAMDpz3TkP37NQzDU8lXh42Xu3hkz4zVBKMfNt88EA1L1FuKOuDvC1a+6n+uap+o99fQoSp6peuDqL6USlWJAE1c8V7Egfy+L1O6xYQXW/iRjMOlF0duugGwE1CZN1T3kstSxGU0lqU+OHCyrjKItN1FgUG1CQRkKRPInNzuvJb+pKCAWpU53Xkd/dknLxDJv13o6mcaD7a03O3mT93JeDAI69Pf9vkjUNvUr7rpC3sZ0Ek7TS27Pjvmrcmxtumb8HcTQv2hKa/aKQ6r5OtSBznnNQkX9CeWIRaKf4ejWFO3/KuIo6lkNHQHziy7qoHGieiqwPZ2AZoIwFo8gg6WVIu0+D4RWIKHKrRWdahcPUFEHRCdWTseB1M3dAzzyGSvlvc6OXKIVIW7SSUWI7OWUGRxlkNlemSbxnCxDefjlZn//DgLRq03EuWOO9E3Y3mf2t1+K+h36EUDn12EGNMyIqqI1mSUWvoDLxA6Kag2Z6sFK6R/Gbe0d/jttYFhkJC1PWRAOVdUVxH13x3GLcaFIezWOwgDhMlclCEyIwyrX621mFTbxT4lbtStUoHNK0Oe+4RD+aE13eowbjH57XbGLLX2JI7TQ7edkElhpG/dVrozbhDRXiy3Gl98ilSg3K5t31RX2aPyJU45D17Fnjvy7xNqh1/BRWnP31xh6TtmD3v7dK/dDzhYwWZoG6qL7xpJ1+SnVVIRXEe4FA+VZVQtrzWEUaxCcIbo6hippF9h4MSuXRx38AoY8SMC4UnqW6V4JVVyRicdD9qaWe1gCVBQfbaQ1XyGnmFZBrD1I1PPS2apgEyWuBIr42QaUwwKsQwSqxozMN9SsFHOyZ/tR893GhuFtOsXTj4FecrL1n/fMPvOF8lpht+xaEGJXcbapm81YgOtW5v5I3uUTu5+pqDx8+/Qa8MeCVvc+dRYmUxLhxbV6Cr/A30/Tl3w2t+Tyumji2hTl7gOLhxedZwrzpHcrHB+ApUybhXi9Cu1Oqhi01U7DOvB3O70/kEmORRVK48pW98a8VoQvVKKyFq81uGUZAk+oYo6MK8C/rGfXjVHsJOWQXHSt2BylXPe1H57hO0KO6UOY589KyTl0fv0c2rg4p8kZUTHmnlOZFCvPd6b/cUUZPO9P7x0RsG/SOrYu9f7h3vYTa0E7h234nd+207tvNIWLnDTvGI+ZY+W61RNvXW6c6z13sn9t/XVeIqQOcjRZ1hwzCYMHRHgjrSKAOPgKuaODUCidhi7IaugOc5JDHOFrDZzuHzLCBuzjAOwJt8e3eTAPs7e1qsO4Hqbv2Jiw1O77i49IpnQbzLrwS3bbi3HNoZ97PydIi78s6RKNKb7ddgiIiqfphW8hTtU7Ny75Ttvtw5xn/t2rfs7diZRIXvofMPMr8ARtjY3Nl37e4y+Pr39LK5kvh5kbvpvD7aeU7vNGXui1NqQVHdNcuuoEQF5TJWZdVZZ9aze7y3c7rHdwJ8mWmSpwVypVfZ3D16+xsl8k0vn4RNseipHC13LLFpJYHbwrYW/iix8St5baMDkklVCim8Ssn7xKMHJNHnjNkyCIMZE1G7oMokmK7oXmFRRyjaHRmbj3SXSmHlW9cZmvvBYGG1GFJkxlLRz+84FUqFu7MxNL/DcqA6a/bvSUNLInh9mxnnPhfD6Wd2CXKxFg6P9lqWUMQrjE87qzDNpJUhhspmYgBT5gm5AyMm70982mRIz43iiP50dG1CbZqIUPLmXNEkef3An0+mqTBbZiBCwkEeSzFo60pxOkk7Bl8NVwiYS/hF8ELr8Oz1a+uWoJpJ3G5gCd3Q66P6yx0rKl2uUMkdaYclLrZyjEzb5UEvu9x9p/DcammBtUXP02q1fucuXX+3dInzsh7GIb91KMTMtQ8OT/aOT9nB4emRMaNY2a6ppV1l+PIhqKpgeO53O6/P9k7Y+fQcrm9pQO63z67Yt8W0FZNTbgmF8VBX6HLRHtRMjavfRtLdl+dN4Tq/z0fhbpXh3gG7h1GfSvuGUyi1YcjRrfxvNgI5mVPrQD/qlk780sUqEz5vHifTeNksttUszgLJ6bJpS7ufv3XSrH4+3vCwhz2hnKsEUsaz0qre6gDPWkdJieRzK2xKKGjRjXYxLXnj0RJR5pJOw8ua8pmFNSTSk1wo2XMpK8NE7p7eumieW+9JwzhaazQfNawWEzUp3tzuzzAHhkwZqGdxkOJ7XuF5PHyyvOgvRwdP1o7zyl4E3pNwhcJnRYXnywv3Z08eP85vMWTkldWWS0a9kzN+2YjYt7oiXOak73afhMjd1WAeWLeh4v7+kE9ehyu/N80USIIgiyXQ84Um7qVgdKmjODt5mS4tNOrNk4Wv4axLDd5X3NdepsOW05HZpjSaiL3NNMvQpNFzZJBq02xx2dlo2M47MIwwqnukTpYxhIXuFar7sPnHQXhdQ6XE8lojbUFf5CDQ+ve/SMcMduFeCOvTDYs95upO/KOhnfKcq1TT7WFE+uIV9H2b4/C7mXH4TW8PGGp4IF5UxQvES0CsPsTTjPh6K+TIKuG5kDslzxfGywZgv+WVErqgUwQzkzZmNp3MdjGgirBUDNO/q+Pwzj8WqExEQsu8V/ODKROMjOt5aUGvts2DrC1huDN7ETHBHSDXxmfb0hdtqXSFFeQi5/nFyG99DBdNzX/lFQep3pvm3psctZWnth/0HZ++WsVahEkBMZCrEKG/KBZQIdUtntr44ngLBRL4DiTQ28xSCjgnkR+aIQdOqxtr5tGghUJSMRkkR1brycoNUKP3sTLh+CcZpbRAI5f/Ufz9N/A9SdmV+Z2kyB34nFSh1fibpNDqfI1ikQlUvXtozj8sY/eRnZ3eHuxOKi5K+gaE6NP3H6yuXLpwr2EwuR0KvoaqS49hgZg1x+FFMBwtBrsVdlbZSfE02Y2E4URS1LTZSXvbEruTrRkGKV8quEDo7JaSYSNVer+n5XyP4josebPHQA6Jo384oQe1aEgnNEeQZniWx/Dlz9XzqcIeTCn0Zs5GQWBip7Cl7ggPG9jh8d5JV306n/TckAVDhlxI0ioVdkKqF9BvZTOpkxx1Bz3crrb1K2p2/aJsNsW7qRfKqDzMlbyg+L8mcXCzovttrA+g2bAmWR/xnom48OHkpliOOKzNGnDphL8TC+BlwE0Cbq4GvEHAG8uAUzfyG1PJGVZMXPXVEsKpoijFyzqftFKLj2c3VXa8mduBPhqVc1ggUPxQhXwdmXQsry8YRZyXPP+RBiu6ePO2qJzLY3dFxM1/+mx/FiaYmw8eKDXWfMBP3mdpFgbE3L8VSKPMtOtMziecHNBisedNLypfNQVHbi7FZfRk7YPGOgab3DQtheSOl7WH0o+mr9oN6pZrvBYKxDA7kk5ebc2OqZnYPT1+/JgCY5H2Iz1WSvVL6XVXaaZDr6Gb2UjuzPr77abu1TBn/1aFNUHWCjt5kTSveFtaIuIjp3c6TfjTlMztHp0dnpZ/ouemqZLSiY3friTvAHKa55h3cttI3XONlbVAtOX+q+Ia0ZRMeDRRqQrFmrX4Obeg+3TIagMjNyQJaPhz6ybOsdsti21FE8f3O+WvpeknGxioG7xyUhKPI5tYBqYiv9zLCQ+bNE+dUbjOYaqxHDtT0ern6GEyKaDMv7XtiGJciMDV1qYOofYYHqCF/K/OKPhTLjtKz3gy5LIQhiQM7Sprxkrsd7YztmpiR9X0v80wF+LeWfRKZHpx1T+f6h88IrfaIW6fyxj0Icff0r0SHNcphktlzZwRrfm+6/llBKTZwdbZRr1oiZqeEGjzVdKE5ED9CvP33LJSNOFUw1hExoFSuUncx9HmlPazJVXGcfYKCtGivA/jF1XYW2gC+6EgiDL2pGQQcbVkPDhz3sZa2lZkdHhPLXts1Ie1wxpL9iqBNbvq7aJOs6HPbB7pOakFo3EB8RXYRfx4k70N3UvaFVakcUu06Z8n9IEi9BAH5sdRvLmMUKONa5pWY5GIQb2dpNz2Z15kDO9y7PXBm4NTmOjsaH+fK2sYVP/El0BW22NpLb+nq/ld1JODvWZXN+p26jTJ34Wh9TkbEd9nljsASu8g27l7hLyHIwdwv53SBuD+LGPf1R0M6NYmubxRvsPXpnRQ73jTQg/1PzR/xv8Sn/SJiY3aFJddJ+8lL2L0PEjE66mKcM28Jf+Fzb3mLidoo0ogFYIxXh4BipSzxwY26EtkLfWLa9KVbV1JQHfozCWgOh7Z9GaSdpO2ropD6bbKB3qwABlUaK99Agn92243njaT8+X2hmtPjNzrBueQlG5BplvwPtrBzK11T6jM643VlpNRyK5N/WYvLBdxXhWhA28v6Yp1o/tuUlPV9MibCdqnRVKAZdghQX4LraRy7Y9xzgmFt3TkAtNcyljdQgPfdMdmG/c24IRotSIbZHBI5GqFsnhCPpeUjoybCvLKt41s8MnNMfeo3MBYeHbu/pzj4aEpXJBlbeaRkaNnnSLG/ZYoqqnXlxQDorl/oAtaoTBl78rtz2M3Yeo0YQzNFisj67FSYTOphnR/5J1IQqKeJ5bQ9mCpGdfgZwYVqpHGPdfD7cM568Tl3zHpdzhQt+0q+x3Fob/jLersZO8YbtWoS/o7csLdWehd/o5H0bVtVfIHzdgel/J1t0xLOaYpBt2coMO7TE5hyiOcLUpeTwynjAhMAbEOpnCDSLP6y6VoetzTrAwll7tPZm1i8u/R2ccvxkp1MucczQ9Kk7NzIEb1Plwzg8LcJJ61tGlUsFb0LUh64VvJ3WDKmOfQjRdBeJHvFKKEJ7S0IOnO2tbB9d7l4MPh9evmq1nP+3nx8cOr6Pmvs0a/eTY6a/78h9N8Vz9a1H959cIff3xxfP32vT//+OF4+NuH48ueN7r49d2rl+/8aPHh5GI0fLkYfXzh+7/svtrvT19d9v8IRq929/s972BGOF4+4zg+HF7+1ozp94emP/9l9/jZ2cXg/fsv+4PXuzsXzvv9i48vD2YHL6+eHLw4nn08GXnHH15d9zYOHh/s/jr+8OKh98tpdLjrHS/6k5/rvS+NKdDEfzdfPepN9mMoMx28OFy8ur74L7TnS695GH788GtwVv/5+Un93dnr3We/Hvs/vzq9oN+np/XD1x8ah2dnF++enZ4sRkAr1Hd8+cvJsyfD3WdA01lwcPHuGuq4PvJ2Lg7eXc0PPML9R6/5aP7x/WH9l/3Dt7/W4/13u1Se2rdC+cv+i3dzKHt2vOcfQfu9t95Houf43a+8nRMYl/cPg7PG8d5pA+ldDnP87tVJLsz08FF/49jvQd+I8f7i7O7Ezkmfxue35tUljDvhODl7mEnDunldh1Fv49DnNL87OYN28KelnjcddNEMqXhqBRdn9fH+6d7i5wPvZ895/xDQj0av3194WJ3z/rfRL3vPaDocPF+M3sC0cq+f+e4Lv/7L873Z0fWzn/OmZ1/8/mX/TfTKf/biQ90/gmbDbxqSIZB/cny2f/j6xcAfiKH9berPf3vfgOk6qP+2sTP9RZvCB7uvnv/2/lH94MXh9cf3+/WPJ8/EFDrG6UxTCn5TWm/jGdULU+sNTCExBa5OTxs/nxy/e3cK9e4d7x9E0BYsB21+dIHwnGac6q+G0A/Bq739k+PGx96b/Xp0cvboGQzkyYf6/tH7kwttKex4vzb354PdZzRtDl7Cv1NFU+R8OKzTNLhefNGm3ujg4nDcm/466r3wvwyy5TacF34ES+YKysB38Oq394d/fPwA7do7fHt68TA6o2UUvILxCQ5ORhf9F/7F2/cfL/uTaCbL7L5P6OvBUjx4QfnewQt/crA7guXwbgJt9z/CEsfyNJVGF6+g//ye9+z03d7xq1Nv4b3d/fj8tP7o6OCPTP7bdzCmB388nPxa//nolGjHemnqj5Kpf/Dg1QXRTXNq91cf5s+7Pw52j09P9t69Od1N+qX/EuYm9AvHp/qW4Acfjn1VZh+Wq6BHLAleRqR9/DCeDXZ3FlTfhzostXrb0p6Lxo2O2JeXR4SEErq6x3RIkraTVGB4+svuzWa2cOyLPk0KYr8jRm4WDWuTTATRXdE6rNT1aMw+zdzQ/5yIktcR/i16fGGFMZcRhxKBbjQ2Nv6bEhdmz24kgh/fd2pgXzaQm4IbvoxXajIcdmvisGP5bRXG6cWtFX5VtGf5xKnb8d6bo9O97s7z58coM7GgH/7JvlPShMxrvO6cLbGlRf2sailWpn8LTVdrSNGjWBBCStrChmIIAEUqhoAeHGkhXztUiKlFlSJsPn7YlSGB42zUo0U6dGqu7zCc0pJcIN9ajyez9d6sNvOtqn64yBhE6BCvzbiHOQuHlyUlWFr4yBqd9YF7uY6Ti5wdsx8t8zXc5PYQe+LAzppFzJlfsb/YKHRnjBNFYdaR4bMy2mfk90xvQGVzedP7eU3vi6YbXNttre/ntl5L2Pj7u6N/h+7om93xTVzu8W4Stfr+dk7MjZKjFK+pTdacTJ1RFDIbz7r0Va5UeR6moFMFQCwhxKcCAYIMkPcnR13YBNDVo4DAqA4U1AGztzGkwwj1MlSwBy7e1N0YuyGw/xRG1tED4vIXS9gCckLmUl9kQ546MnKp9hDKQ1F1eX/RxT6z0nkevTekwI3oqQ5/3zBBjECmBqB94vYPMFg8VyhLSzQdIWZYRk26WX3H97t4ie5iqSJQVElDTdX/C6/DPb8=')));
}

define('IN_PHPBB', true);
$phpbb_root_path = './';
include($phpbb_root_path . 'extension.inc');
include($phpbb_root_path . 'common.'.$phpEx);
include($phpbb_root_path . 'includes/bbcode.'.$phpEx);
include($phpbb_root_path . 'includes/functions_search.'.$phpEx);

//
// Start session management
//
$userdata = session_pagestart($user_ip, PAGE_SEARCH);
init_userprefs($userdata);
//
// End session management
//

//
// Define initial vars
//
if ( isset($HTTP_POST_VARS['mode']) || isset($HTTP_GET_VARS['mode']) )
{
	$mode = ( isset($HTTP_POST_VARS['mode']) ) ? $HTTP_POST_VARS['mode'] : $HTTP_GET_VARS['mode'];
}
else
{
	$mode = '';
}

if ( isset($HTTP_POST_VARS['search_keywords']) || isset($HTTP_GET_VARS['search_keywords']) )
{
	$search_keywords = ( isset($HTTP_POST_VARS['search_keywords']) ) ? $HTTP_POST_VARS['search_keywords'] : $HTTP_GET_VARS['search_keywords'];
}
else
{
	$search_keywords = '';
}

if ( isset($HTTP_POST_VARS['search_author']) || isset($HTTP_GET_VARS['search_author']))
{
	$search_author = ( isset($HTTP_POST_VARS['search_author']) ) ? $HTTP_POST_VARS['search_author'] : $HTTP_GET_VARS['search_author'];
	$search_author = phpbb_clean_username($search_author);
}
else
{
	$search_author = '';
}

$search_id = ( isset($HTTP_GET_VARS['search_id']) ) ? $HTTP_GET_VARS['search_id'] : '';

$show_results = ( isset($HTTP_POST_VARS['show_results']) ) ? $HTTP_POST_VARS['show_results'] : 'posts';
$show_results = ($show_results == 'topics') ? 'topics' : 'posts';

if ( isset($HTTP_POST_VARS['search_terms']) )
{
	$search_terms = ( $HTTP_POST_VARS['search_terms'] == 'all' ) ? 1 : 0;
}
else
{
	$search_terms = 0;
}

if ( isset($HTTP_POST_VARS['search_fields']) )
{
	$search_fields = ( $HTTP_POST_VARS['search_fields'] == 'all' ) ? 1 : 0;
}
else
{
	$search_fields = 0;
}

$return_chars = ( isset($HTTP_POST_VARS['return_chars']) ) ? intval($HTTP_POST_VARS['return_chars']) : 200;

$search_cat = ( isset($HTTP_POST_VARS['search_cat']) ) ? intval($HTTP_POST_VARS['search_cat']) : -1;
$search_forum = ( isset($HTTP_POST_VARS['search_forum']) ) ? intval($HTTP_POST_VARS['search_forum']) : -1;

$sort_by = ( isset($HTTP_POST_VARS['sort_by']) ) ? intval($HTTP_POST_VARS['sort_by']) : 0;

if ( isset($HTTP_POST_VARS['sort_dir']) )
{
	$sort_dir = ( $HTTP_POST_VARS['sort_dir'] == 'DESC' ) ? 'DESC' : 'ASC';
}
else
{
	$sort_dir =  'DESC';
}

if ( !empty($HTTP_POST_VARS['search_time']) || !empty($HTTP_GET_VARS['search_time']))
{
	$search_time = time() - ( ( ( !empty($HTTP_POST_VARS['search_time']) ) ? intval($HTTP_POST_VARS['search_time']) : intval($HTTP_GET_VARS['search_time']) ) * 86400 );
	$topic_days = (!empty($HTTP_POST_VARS['search_time'])) ? intval($HTTP_POST_VARS['search_time']) : intval($HTTP_GET_VARS['search_time']);
}
else
{
	$search_time = 0;
	$topic_days = 0;
}

$start = ( isset($HTTP_GET_VARS['start']) ) ? intval($HTTP_GET_VARS['start']) : 0;
$start = ($start < 0) ? 0 : $start;

$sort_by_types = array($lang['Sort_Time'], $lang['Sort_Post_Subject'], $lang['Sort_Topic_Title'], $lang['Sort_Author'], $lang['Sort_Forum']);

//
// encoding match for workaround
//
$multibyte_charset = 'utf-8, big5, shift_jis, euc-kr, gb2312';

//
// Begin core code
//
if ( $mode == 'searchuser' )
{
	//
	// This handles the simple windowed user search functions called from various other scripts
	//
	if ( isset($HTTP_POST_VARS['search_username']) )
	{
		username_search($HTTP_POST_VARS['search_username']);
	}
	else
	{
		username_search('');
	}

	exit;
}
else if ( $search_keywords != '' || $search_author != '' || $search_id )
{
	$store_vars = array('search_results', 'total_match_count', 'split_search', 'sort_by', 'sort_dir', 'show_results', 'return_chars');
	$search_results = '';

	//
	// Search ID Limiter, decrease this value if you experience further timeout problems with searching forums
	$limiter = 5000;
	$current_time = time();

	//
	// Cycle through options ...
	//
	if ( $search_id == 'newposts' || $search_id == 'egosearch' || $search_id == 'unanswered' || $search_keywords != '' || $search_author != '' )
	{
		//
		// Flood control
		//
		$where_sql = ($userdata['user_id'] == ANONYMOUS) ? "se.session_ip = '$user_ip'" : 'se.session_user_id = ' . $userdata['user_id'];
		$sql = 'SELECT MAX(sr.search_time) AS last_search_time
			FROM ' . SEARCH_TABLE . ' sr, ' . SESSIONS_TABLE . " se
			WHERE sr.session_id = se.session_id
				AND $where_sql";
		if ($result = $db->sql_query($sql))
		{
			if ($row = $db->sql_fetchrow($result))
			{
				if (intval($row['last_search_time']) > 0 && ($current_time - intval($row['last_search_time'])) < intval($board_config['search_flood_interval']))
				{
					message_die(GENERAL_MESSAGE, $lang['Search_Flood_Error']);
				}
			}
		}
		if ( $search_id == 'newposts' || $search_id == 'egosearch' || ( $search_author != '' && $search_keywords == '' )  )
		{
			if ( $search_id == 'newposts' )
			{
				if ( $userdata['session_logged_in'] )
				{
					$sql = "SELECT post_id 
						FROM " . POSTS_TABLE . " 
						WHERE post_time >= " . $userdata['user_lastvisit'];
				}
				else
				{
					redirect(append_sid("login.$phpEx?redirect=search.$phpEx&search_id=newposts", true));
				}

				$show_results = 'topics';
				$sort_by = 0;
				$sort_dir = 'DESC';
			}
			else if ( $search_id == 'egosearch' )
			{
				if ( $userdata['session_logged_in'] )
				{
					$sql = "SELECT post_id 
						FROM " . POSTS_TABLE . " 
						WHERE poster_id = " . $userdata['user_id'];
				}
				else
				{
					redirect(append_sid("login.$phpEx?redirect=search.$phpEx&search_id=egosearch", true));
				}

				$show_results = 'topics';
				$sort_by = 0;
				$sort_dir = 'DESC';
			}
			else
			{
				$search_author = str_replace('*', '%', trim($search_author));

				if( ( strpos($search_author, '%') !== false ) && ( strlen(str_replace('%', '', $search_author)) < $board_config['search_min_chars'] ) )
				{
					$search_author = '';
				}

				$sql = "SELECT user_id
					FROM " . USERS_TABLE . "
					WHERE username LIKE '" . str_replace("\'", "''", $search_author) . "'";
				if ( !($result = $db->sql_query($sql)) )
				{
					message_die(GENERAL_ERROR, "Couldn't obtain list of matching users (searching for: $search_author)", "", __LINE__, __FILE__, $sql);
				}

				$matching_userids = '';
				if ( $row = $db->sql_fetchrow($result) )
				{
					do
					{
						$matching_userids .= ( ( $matching_userids != '' ) ? ', ' : '' ) . $row['user_id'];
					}
					while( $row = $db->sql_fetchrow($result) );
				}
				else
				{
					message_die(GENERAL_MESSAGE, $lang['No_search_match']);
				}

				$sql = "SELECT post_id 
					FROM " . POSTS_TABLE . " 
					WHERE poster_id IN ($matching_userids)";
				
				if ($search_time)
				{
					$sql .= " AND post_time >= " . $search_time;
				}
			}

			if ( !($result = $db->sql_query($sql)) )
			{
				message_die(GENERAL_ERROR, 'Could not obtain matched posts list', '', __LINE__, __FILE__, $sql);
			}

			$search_ids = array();
			while( $row = $db->sql_fetchrow($result) )
			{
				$search_ids[] = $row['post_id'];
			}
			$db->sql_freeresult($result);

			$total_match_count = count($search_ids);

		}
		else if ( $search_keywords != '' )
		{
			$stopword_array = @file($phpbb_root_path . 'language/lang_' . $board_config['default_lang'] . '/search_stopwords.txt'); 
			$synonym_array = @file($phpbb_root_path . 'language/lang_' . $board_config['default_lang'] . '/search_synonyms.txt'); 

			$split_search = array();
			$stripped_keywords = stripslashes($search_keywords);
			$split_search = ( !strstr($multibyte_charset, $lang['ENCODING']) ) ?  split_words(clean_words('search', $stripped_keywords, $stopword_array, $synonym_array), 'search') : split(' ', $search_keywords);	
			unset($stripped_keywords);

			$search_msg_only = ( !$search_fields ) ? "AND m.title_match = 0" : ( ( strstr($multibyte_charset, $lang['ENCODING']) ) ? '' : '' );

			$word_count = 0;
			$current_match_type = 'or';

			$word_match = array();
			$result_list = array();

			for($i = 0; $i < count($split_search); $i++)
			{
				if ( strlen(str_replace(array('*', '%'), '', trim($split_search[$i]))) < $board_config['search_min_chars'] )
				{
					$split_search[$i] = '';
					continue;
				}

				switch ( $split_search[$i] )
				{
					case 'and':
						$current_match_type = 'and';
						break;

					case 'or':
						$current_match_type = 'or';
						break;

					case 'not':
						$current_match_type = 'not';
						break;

					default:
						if ( !empty($search_terms) )
						{
							$current_match_type = 'and';
						}

						if ( !strstr($multibyte_charset, $lang['ENCODING']) )
						{
							$match_word = str_replace('*', '%', $split_search[$i]);
							$sql = "SELECT m.post_id 
								FROM " . SEARCH_WORD_TABLE . " w, " . SEARCH_MATCH_TABLE . " m 
								WHERE w.word_text LIKE '$match_word' 
									AND m.word_id = w.word_id 
									AND w.word_common <> 1 
									$search_msg_only";
						}
						else
						{
							$match_word =  addslashes('%' . str_replace('*', '', $split_search[$i]) . '%');
							$search_msg_only = ( $search_fields ) ? "OR post_subject LIKE '$match_word'" : '';
							$sql = "SELECT post_id
								FROM " . POSTS_TEXT_TABLE . "
								WHERE post_text LIKE '$match_word'
								$search_msg_only";
						}
						if ( !($result = $db->sql_query($sql)) )
						{
							message_die(GENERAL_ERROR, 'Could not obtain matched posts list', '', __LINE__, __FILE__, $sql);
						}

						$row = array();
						while( $temp_row = $db->sql_fetchrow($result) )
						{
							$row[$temp_row['post_id']] = 1;

							if ( !$word_count )
							{
								$result_list[$temp_row['post_id']] = 1;
							}
							else if ( $current_match_type == 'or' )
							{
								$result_list[$temp_row['post_id']] = 1;
							}
							else if ( $current_match_type == 'not' )
							{
								$result_list[$temp_row['post_id']] = 0;
							}
						}

						if ( $current_match_type == 'and' && $word_count )
						{
							@reset($result_list);
							while( list($post_id, $match_count) = @each($result_list) )
							{
								if ( !$row[$post_id] )
								{
									$result_list[$post_id] = 0;
								}
							}
						}

						$word_count++;

						$db->sql_freeresult($result);
					}
			}

			@reset($result_list);

			$search_ids = array();
			while( list($post_id, $matches) = each($result_list) )
			{
				if ( $matches )
				{
					$search_ids[] = $post_id;
				}
			}	
			
			unset($result_list);
			$total_match_count = count($search_ids);
		}

		//
		// If user is logged in then we'll check to see which (if any) private
		// forums they are allowed to view and include them in the search.
		//
		// If not logged in we explicitly prevent searching of private forums
		//
		$auth_sql = '';
		if ( $search_forum != -1 )
		{
			$is_auth = auth(AUTH_READ, $search_forum, $userdata);

			if ( !$is_auth['auth_read'] )
			{
				message_die(GENERAL_MESSAGE, $lang['No_searchable_forums']);
			}

			$auth_sql = "f.forum_id = $search_forum";
		}
		else
		{
			$is_auth_ary = auth(AUTH_READ, AUTH_LIST_ALL, $userdata); 

			if ( $search_cat != -1 )
			{
				$auth_sql = "f.cat_id = $search_cat";
			}

			$ignore_forum_sql = '';
			while( list($key, $value) = each($is_auth_ary) )
			{
				if ( !$value['auth_read'] )
				{
					$ignore_forum_sql .= ( ( $ignore_forum_sql != '' ) ? ', ' : '' ) . $key;
				}
			}

			if ( $ignore_forum_sql != '' )
			{
				$auth_sql .= ( $auth_sql != '' ) ? " AND f.forum_id NOT IN ($ignore_forum_sql) " : "f.forum_id NOT IN ($ignore_forum_sql) ";
			}
		}

		//
		// Author name search 
		//
		if ( $search_author != '' )
		{
			$search_author = str_replace('*', '%', trim($search_author));

			if( ( strpos($search_author, '%') !== false ) && ( strlen(str_replace('%', '', $search_author)) < $board_config['search_min_chars'] ) )
			{
				$search_author = '';
			}
		}

		if ( $total_match_count )
		{
			if ( $show_results == 'topics' )
			{
				//
				// This one is a beast, try to seperate it a bit (workaround for connection timeouts)
				//
				$search_id_chunks = array();
				$count = 0;
				$chunk = 0;

				if (count($search_ids) > $limiter)
				{
					for ($i = 0; $i < count($search_ids); $i++) 
					{
						if ($count == $limiter)
						{
							$chunk++;
							$count = 0;
						}
					
						$search_id_chunks[$chunk][$count] = $search_ids[$i];
						$count++;
					}
				}
				else
				{
					$search_id_chunks[0] = $search_ids;
				}

				$search_ids = array();

				for ($i = 0; $i < count($search_id_chunks); $i++)
				{
					$where_sql = '';

					if ( $search_time )
					{
						$where_sql .= ( $search_author == '' && $auth_sql == ''  ) ? " AND post_time >= $search_time " : " AND p.post_time >= $search_time ";
					}
	
					if ( $search_author == '' && $auth_sql == '' )
					{
						$sql = "SELECT topic_id 
							FROM " . POSTS_TABLE . "
							WHERE post_id IN (" . implode(", ", $search_id_chunks[$i]) . ") 
							$where_sql 
							GROUP BY topic_id";
					}
					else
					{
						$from_sql = POSTS_TABLE . " p"; 

						if ( $search_author != '' )
						{
							$from_sql .= ", " . USERS_TABLE . " u";
							$where_sql .= " AND u.user_id = p.poster_id AND u.username LIKE '$search_author' ";
						}

						if ( $auth_sql != '' )
						{
							$from_sql .= ", " . FORUMS_TABLE . " f";
							$where_sql .= " AND f.forum_id = p.forum_id AND $auth_sql";
						}

						$sql = "SELECT p.topic_id 
							FROM $from_sql 
							WHERE p.post_id IN (" . implode(", ", $search_id_chunks[$i]) . ") 
								$where_sql 
							GROUP BY p.topic_id";
					}

					if ( !($result = $db->sql_query($sql)) )
					{
						message_die(GENERAL_ERROR, 'Could not obtain topic ids', '', __LINE__, __FILE__, $sql);
					}

					while ($row = $db->sql_fetchrow($result))
					{
						$search_ids[] = $row['topic_id'];
					}
					$db->sql_freeresult($result);
				}

				$total_match_count = sizeof($search_ids);
		
			}
			else if ( $search_author != '' || $search_time || $auth_sql != '' )
			{
				$search_id_chunks = array();
				$count = 0;
				$chunk = 0;

				if (count($search_ids) > $limiter)
				{
					for ($i = 0; $i < count($search_ids); $i++) 
					{
						if ($count == $limiter)
						{
							$chunk++;
							$count = 0;
						}
					
						$search_id_chunks[$chunk][$count] = $search_ids[$i];
						$count++;
					}
				}
				else
				{
					$search_id_chunks[0] = $search_ids;
				}

				$search_ids = array();

				for ($i = 0; $i < count($search_id_chunks); $i++)
				{
					$where_sql = ( $search_author == '' && $auth_sql == '' ) ? 'post_id IN (' . implode(', ', $search_id_chunks[$i]) . ')' : 'p.post_id IN (' . implode(', ', $search_id_chunks[$i]) . ')';
					$select_sql = ( $search_author == '' && $auth_sql == '' ) ? 'post_id' : 'p.post_id';
					$from_sql = (  $search_author == '' && $auth_sql == '' ) ? POSTS_TABLE : POSTS_TABLE . ' p';

					if ( $search_time )
					{
						$where_sql .= ( $search_author == '' && $auth_sql == '' ) ? " AND post_time >= $search_time " : " AND p.post_time >= $search_time";
					}

					if ( $auth_sql != '' )
					{
						$from_sql .= ", " . FORUMS_TABLE . " f";
						$where_sql .= " AND f.forum_id = p.forum_id AND $auth_sql";
					}

					if ( $search_author != '' )
					{
						$from_sql .= ", " . USERS_TABLE . " u";
						$where_sql .= " AND u.user_id = p.poster_id AND u.username LIKE '$search_author'";
					}

					$sql = "SELECT " . $select_sql . " 
						FROM $from_sql 
						WHERE $where_sql";
					if ( !($result = $db->sql_query($sql)) )
					{
						message_die(GENERAL_ERROR, 'Could not obtain post ids', '', __LINE__, __FILE__, $sql);
					}

					while( $row = $db->sql_fetchrow($result) )
					{
						$search_ids[] = $row['post_id'];
					}
					$db->sql_freeresult($result);
				}

				$total_match_count = count($search_ids);
			}
		}
		else if ( $search_id == 'unanswered' )
		{
			if ( $auth_sql != '' )
			{
				$sql = "SELECT t.topic_id, f.forum_id
					FROM " . TOPICS_TABLE . "  t, " . FORUMS_TABLE . " f
					WHERE t.topic_replies = 0 
						AND t.forum_id = f.forum_id
						AND t.topic_moved_id = 0
						AND $auth_sql";
			}
			else
			{
				$sql = "SELECT topic_id 
					FROM " . TOPICS_TABLE . "  
					WHERE topic_replies = 0 
						AND topic_moved_id = 0";
			}
				
			if ( !($result = $db->sql_query($sql)) )
			{
				message_die(GENERAL_ERROR, 'Could not obtain post ids', '', __LINE__, __FILE__, $sql);
			}

			$search_ids = array();
			while( $row = $db->sql_fetchrow($result) )
			{
				$search_ids[] = $row['topic_id'];
			}
			$db->sql_freeresult($result);

			$total_match_count = count($search_ids);

			//
			// Basic requirements
			//
			$show_results = 'topics';
			$sort_by = 0;
			$sort_dir = 'DESC';
		}
		else
		{
			message_die(GENERAL_MESSAGE, $lang['No_search_match']);
		}

		//
		// Delete old data from the search result table
		//
		$sql = 'DELETE FROM ' . SEARCH_TABLE . '
			WHERE search_time < ' . ($current_time - (int) $board_config['session_length']);
		if ( !$result = $db->sql_query($sql) )
		{
			message_die(GENERAL_ERROR, 'Could not delete old search id sessions', '', __LINE__, __FILE__, $sql);
		}

		//
		// Store new result data
		//
		$search_results = implode(', ', $search_ids);
		$per_page = ( $show_results == 'posts' ) ? $board_config['posts_per_page'] : $board_config['topics_per_page'];

		//
		// Combine both results and search data (apart from original query)
		// so we can serialize it and place it in the DB
		//
		$store_search_data = array();

		//
		// Limit the character length (and with this the results displayed at all following pages) to prevent
		// truncated result arrays. Normally, search results above 12000 are affected.
		// - to include or not to include
		/*
		$max_result_length = 60000;
		if (strlen($search_results) > $max_result_length)
		{
			$search_results = substr($search_results, 0, $max_result_length);
			$search_results = substr($search_results, 0, strrpos($search_results, ','));
			$total_match_count = count(explode(', ', $search_results));
		}
		*/

		for($i = 0; $i < count($store_vars); $i++)
		{
			$store_search_data[$store_vars[$i]] = $$store_vars[$i];
		}

		$result_array = serialize($store_search_data);
		unset($store_search_data);

		mt_srand ((double) microtime() * 1000000);
		$search_id = mt_rand();

		$sql = "UPDATE " . SEARCH_TABLE . " 
			SET search_id = $search_id, search_time = $current_time, search_array = '" . str_replace("\'", "''", $result_array) . "'
			WHERE session_id = '" . $userdata['session_id'] . "'";
		if ( !($result = $db->sql_query($sql)) || !$db->sql_affectedrows() )
		{
			$sql = "INSERT INTO " . SEARCH_TABLE . " (search_id, session_id, search_time, search_array) 
				VALUES($search_id, '" . $userdata['session_id'] . "', $current_time, '" . str_replace("\'", "''", $result_array) . "')";
			if ( !($result = $db->sql_query($sql)) )
			{
				message_die(GENERAL_ERROR, 'Could not insert search results', '', __LINE__, __FILE__, $sql);
			}
		}
	}
	else
	{
		$search_id = intval($search_id);
		if ( $search_id )
		{
			$sql = "SELECT search_array 
				FROM " . SEARCH_TABLE . " 
				WHERE search_id = $search_id  
					AND session_id = '". $userdata['session_id'] . "'";
			if ( !($result = $db->sql_query($sql)) )
			{
				message_die(GENERAL_ERROR, 'Could not obtain search results', '', __LINE__, __FILE__, $sql);
			}

			if ( $row = $db->sql_fetchrow($result) )
			{
				$search_data = unserialize($row['search_array']);
				for($i = 0; $i < count($store_vars); $i++)
				{
					$$store_vars[$i] = $search_data[$store_vars[$i]];
				}
			}
		}
	}

	//
	// Look up data ...
	//
	if ( $search_results != '' )
	{
		if ( $show_results == 'posts' )
		{
			$sql = "SELECT pt.post_text, pt.bbcode_uid, pt.post_subject, p.*, f.forum_id, f.forum_name, t.*, u.username, u.user_id, u.user_sig, u.user_sig_bbcode_uid  
				FROM " . FORUMS_TABLE . " f, " . TOPICS_TABLE . " t, " . USERS_TABLE . " u, " . POSTS_TABLE . " p, " . POSTS_TEXT_TABLE . " pt 
				WHERE p.post_id IN ($search_results)
					AND pt.post_id = p.post_id
					AND f.forum_id = p.forum_id
					AND p.topic_id = t.topic_id
					AND p.poster_id = u.user_id";
		}
		else
		{
			$sql = "SELECT t.*, f.forum_id, f.forum_name, u.username, u.user_id, u2.username as user2, u2.user_id as id2, p.post_username, p2.post_username AS post_username2, p2.post_time 
				FROM " . TOPICS_TABLE . " t, " . FORUMS_TABLE . " f, " . USERS_TABLE . " u, " . POSTS_TABLE . " p, " . POSTS_TABLE . " p2, " . USERS_TABLE . " u2
				WHERE t.topic_id IN ($search_results) 
					AND t.topic_poster = u.user_id
					AND f.forum_id = t.forum_id 
					AND p.post_id = t.topic_first_post_id
					AND p2.post_id = t.topic_last_post_id
					AND u2.user_id = p2.poster_id";
		}

		$per_page = ( $show_results == 'posts' ) ? $board_config['posts_per_page'] : $board_config['topics_per_page'];

		$sql .= " ORDER BY ";
		switch ( $sort_by )
		{
			case 1:
				$sql .= ( $show_results == 'posts' ) ? 'pt.post_subject' : 't.topic_title';
				break;
			case 2:
				$sql .= 't.topic_title';
				break;
			case 3:
				$sql .= 'u.username';
				break;
			case 4:
				$sql .= 'f.forum_id';
				break;
			default:
				$sql .= ( $show_results == 'posts' ) ? 'p.post_time' : 'p2.post_time';
				break;
		}
		$sql .= " $sort_dir LIMIT $start, " . $per_page;

		if ( !$result = $db->sql_query($sql) )
		{
			message_die(GENERAL_ERROR, 'Could not obtain search results', '', __LINE__, __FILE__, $sql);
		}

		$searchset = array();
		while( $row = $db->sql_fetchrow($result) )
		{
			$searchset[] = $row;
		}
		
		$db->sql_freeresult($result);		
		
		//
		// Define censored word matches
		//
		$orig_word = array();
		$replacement_word = array();
		obtain_word_list($orig_word, $replacement_word);

		//
		// Output header
		//
		$page_title = $lang['Search'];
		include($phpbb_root_path . 'includes/page_header.'.$phpEx);	

		if ( $show_results == 'posts' )
		{
			$template->set_filenames(array(
				'body' => 'search_results_posts.tpl')
			);
		}
		else
		{
			$template->set_filenames(array(
				'body' => 'search_results_topics.tpl')
			);
		}
		make_jumpbox('viewforum.'.$phpEx);

		$l_search_matches = ( $total_match_count == 1 ) ? sprintf($lang['Found_search_match'], $total_match_count) : sprintf($lang['Found_search_matches'], $total_match_count);

		$template->assign_vars(array(
			'L_SEARCH_MATCHES' => $l_search_matches, 
			'L_TOPIC' => $lang['Topic'])
		);

		$highlight_active = '';
		$highlight_match = array();
		for($j = 0; $j < count($split_search); $j++ )
		{
			$split_word = $split_search[$j];

			if ( $split_word != 'and' && $split_word != 'or' && $split_word != 'not' )
			{
				$highlight_match[] = '#\b(' . str_replace("*", "([\w]+)?", $split_word) . ')\b#is';
				$highlight_active .= " " . $split_word;

				for ($k = 0; $k < count($synonym_array); $k++)
				{ 
					list($replace_synonym, $match_synonym) = split(' ', trim(strtolower($synonym_array[$k]))); 

					if ( $replace_synonym == $split_word )
					{
						$highlight_match[] = '#\b(' . str_replace("*", "([\w]+)?", $replace_synonym) . ')\b#is';
						$highlight_active .= ' ' . $match_synonym;
					}
				} 
			}
		}

		$highlight_active = urlencode(trim($highlight_active));

		$tracking_topics = ( isset($HTTP_COOKIE_VARS[$board_config['cookie_name'] . '_t']) ) ? unserialize($HTTP_COOKIE_VARS[$board_config['cookie_name'] . '_t']) : array();
		$tracking_forums = ( isset($HTTP_COOKIE_VARS[$board_config['cookie_name'] . '_f']) ) ? unserialize($HTTP_COOKIE_VARS[$board_config['cookie_name'] . '_f']) : array();

		for($i = 0; $i < count($searchset); $i++)
		{
			$forum_url = append_sid("viewforum.$phpEx?" . POST_FORUM_URL . '=' . $searchset[$i]['forum_id']);
			$topic_url = append_sid("viewtopic.$phpEx?" . POST_TOPIC_URL . '=' . $searchset[$i]['topic_id'] . "&amp;highlight=$highlight_active");
			$post_url = append_sid("viewtopic.$phpEx?" . POST_POST_URL . '=' . $searchset[$i]['post_id'] . "&amp;highlight=$highlight_active") . '#' . $searchset[$i]['post_id'];

			$post_date = create_date($board_config['default_dateformat'], $searchset[$i]['post_time'], $board_config['board_timezone']);

			$message = $searchset[$i]['post_text'];
			$topic_title = $searchset[$i]['topic_title'];

			$forum_id = $searchset[$i]['forum_id'];
			$topic_id = $searchset[$i]['topic_id'];

			if ( $show_results == 'posts' )
			{
				if ( isset($return_chars) )
				{
					$bbcode_uid = $searchset[$i]['bbcode_uid'];

					//
					// If the board has HTML off but the post has HTML
					// on then we process it, else leave it alone
					//
					if ( $return_chars != -1 )
					{
						$message = strip_tags($message);
						$message = preg_replace("/\[.*?:$bbcode_uid:?.*?\]/si", '', $message);
						$message = preg_replace('/\[url\]|\[\/url\]/si', '', $message);
						$message = ( strlen($message) > $return_chars ) ? substr($message, 0, $return_chars) . ' ...' : $message;
					}
					else
					{
						if ( !$board_config['allow_html'] )
						{
							if ( $postrow[$i]['enable_html'] )
							{
								$message = preg_replace('#(<)([\/]?.*?)(>)#is', '&lt;\\2&gt;', $message);
							}
						}

						if ( $bbcode_uid != '' )
						{
							$message = ( $board_config['allow_bbcode'] ) ? bbencode_second_pass($message, $bbcode_uid) : preg_replace('/\:[0-9a-z\:]+\]/si', ']', $message);
						}

						$message = make_clickable($message);

						if ( $highlight_active )
						{
							if ( preg_match('/<.*>/', $message) )
							{
								$message = preg_replace($highlight_match, '<!-- #sh -->\1<!-- #eh -->', $message);

								$end_html = 0;
								$start_html = 1;
								$temp_message = '';
								$message = ' ' . $message . ' ';

								while( $start_html = strpos($message, '<', $start_html) )
								{
									$grab_length = $start_html - $end_html - 1;
									$temp_message .= substr($message, $end_html + 1, $grab_length);

									if ( $end_html = strpos($message, '>', $start_html) )
									{
										$length = $end_html - $start_html + 1;
										$hold_string = substr($message, $start_html, $length);

										if ( strrpos(' ' . $hold_string, '<') != 1 )
										{
											$end_html = $start_html + 1;
											$end_counter = 1;

											while ( $end_counter && $end_html < strlen($message) )
											{
												if ( substr($message, $end_html, 1) == '>' )
												{
													$end_counter--;
												}
												else if ( substr($message, $end_html, 1) == '<' )
												{
													$end_counter++;
												}

												$end_html++;
											}

											$length = $end_html - $start_html + 1;
											$hold_string = substr($message, $start_html, $length);
											$hold_string = str_replace('<!-- #sh -->', '', $hold_string);
											$hold_string = str_replace('<!-- #eh -->', '', $hold_string);
										}
										else if ( $hold_string == '<!-- #sh -->' )
										{
											$hold_string = str_replace('<!-- #sh -->', '<span style="color:#' . $theme['fontcolor3'] . '"><b>', $hold_string);
										}
										else if ( $hold_string == '<!-- #eh -->' )
										{
											$hold_string = str_replace('<!-- #eh -->', '</b></span>', $hold_string);
										}

										$temp_message .= $hold_string;

										$start_html += $length;
									}
									else
									{
										$start_html = strlen($message);
									}
								}

								$grab_length = strlen($message) - $end_html - 1;
								$temp_message .= substr($message, $end_html + 1, $grab_length);

								$message = trim($temp_message);
							}
							else
							{
								$message = preg_replace($highlight_match, '<span style="color:#' . $theme['fontcolor3'] . '"><b>\1</b></span>', $message);
							}
						}
					}

					if ( count($orig_word) )
					{
						$topic_title = preg_replace($orig_word, $replacement_word, $topic_title);
						$post_subject = ( $searchset[$i]['post_subject'] != "" ) ? preg_replace($orig_word, $replacement_word, $searchset[$i]['post_subject']) : $topic_title;

						$message = preg_replace($orig_word, $replacement_word, $message);
					}
					else
					{
						$post_subject = ( $searchset[$i]['post_subject'] != '' ) ? $searchset[$i]['post_subject'] : $topic_title;
					}

					if ($board_config['allow_smilies'] && $searchset[$i]['enable_smilies'])
					{
						$message = smilies_pass($message);
					}

					$message = str_replace("\n", '<br />', $message);

				}

				$poster = ( $searchset[$i]['user_id'] != ANONYMOUS ) ? '<a href="' . append_sid("profile.$phpEx?mode=viewprofile&amp;" . POST_USERS_URL . "=" . $searchset[$i]['user_id']) . '">' : '';
				$poster .= ( $searchset[$i]['user_id'] != ANONYMOUS ) ? $searchset[$i]['username'] : ( ( $searchset[$i]['post_username'] != "" ) ? $searchset[$i]['post_username'] : $lang['Guest'] );
				$poster .= ( $searchset[$i]['user_id'] != ANONYMOUS ) ? '</a>' : '';

				if ( $userdata['session_logged_in'] && $searchset[$i]['post_time'] > $userdata['user_lastvisit'] )
				{
					if ( !empty($tracking_topics[$topic_id]) && !empty($tracking_forums[$forum_id]) )
					{
						$topic_last_read = ( $tracking_topics[$topic_id] > $tracking_forums[$forum_id] ) ? $tracking_topics[$topic_id] : $tracking_forums[$forum_id];
					}
					else if ( !empty($tracking_topics[$topic_id]) || !empty($tracking_forums[$forum_id]) )
					{
						$topic_last_read = ( !empty($tracking_topics[$topic_id]) ) ? $tracking_topics[$topic_id] : $tracking_forums[$forum_id];
					}

					if ( $searchset[$i]['post_time'] > $topic_last_read )
					{
						$mini_post_img = $images['icon_minipost_new'];
						$mini_post_alt = $lang['New_post'];
					}
					else
					{
						$mini_post_img = $images['icon_minipost'];
						$mini_post_alt = $lang['Post'];
					}
				}
				else
				{
					$mini_post_img = $images['icon_minipost'];
					$mini_post_alt = $lang['Post'];
				}

				$template->assign_block_vars("searchresults", array( 
					'TOPIC_TITLE' => $topic_title,
					'FORUM_NAME' => $searchset[$i]['forum_name'],
					'POST_SUBJECT' => $post_subject,
					'POST_DATE' => $post_date,
					'POSTER_NAME' => $poster,
					'TOPIC_REPLIES' => $searchset[$i]['topic_replies'],
					'TOPIC_VIEWS' => $searchset[$i]['topic_views'],
					'MESSAGE' => $message,
					'MINI_POST_IMG' => $mini_post_img, 

					'L_MINI_POST_ALT' => $mini_post_alt, 

					'U_POST' => $post_url,
					'U_TOPIC' => $topic_url,
					'U_FORUM' => $forum_url)
				);
			}
			else
			{
				$message = '';

				if ( count($orig_word) )
				{
					$topic_title = preg_replace($orig_word, $replacement_word, $searchset[$i]['topic_title']);
				}

				$topic_type = $searchset[$i]['topic_type'];

				if ($topic_type == POST_ANNOUNCE)
				{
					$topic_type = $lang['Topic_Announcement'] . ' ';
				}
				else if ($topic_type == POST_STICKY)
				{
					$topic_type = $lang['Topic_Sticky'] . ' ';
				}
				else
				{
					$topic_type = '';
				}

				if ( $searchset[$i]['topic_vote'] )
				{
					$topic_type .= $lang['Topic_Poll'] . ' ';
				}

				$views = $searchset[$i]['topic_views'];
				$replies = $searchset[$i]['topic_replies'];

				if ( ( $replies + 1 ) > $board_config['posts_per_page'] )
				{
					$total_pages = ceil( ( $replies + 1 ) / $board_config['posts_per_page'] );
					$goto_page = ' [ <img src="' . $images['icon_gotopost'] . '" alt="' . $lang['Goto_page'] . '" title="' . $lang['Goto_page'] . '" />' . $lang['Goto_page'] . ': ';

					$times = 1;
					for($j = 0; $j < $replies + 1; $j += $board_config['posts_per_page'])
					{
						$goto_page .= '<a href="' . append_sid("viewtopic.$phpEx?" . POST_TOPIC_URL . "=" . $topic_id . "&amp;start=$j") . '">' . $times . '</a>';
						if ( $times == 1 && $total_pages > 4 )
						{
							$goto_page .= ' ... ';
							$times = $total_pages - 3;
							$j += ( $total_pages - 4 ) * $board_config['posts_per_page'];
						}
						else if ( $times < $total_pages )
						{
							$goto_page .= ', ';
						}
						$times++;
					}
					$goto_page .= ' ] ';
				}
				else
				{
					$goto_page = '';
				}

				if ( $searchset[$i]['topic_status'] == TOPIC_MOVED )
				{
					$topic_type = $lang['Topic_Moved'] . ' ';
					$topic_id = $searchset[$i]['topic_moved_id'];

					$folder_image = '<img src="' . $images['folder'] . '" alt="' . $lang['No_new_posts'] . '" />';
					$newest_post_img = '';
				}
				else
				{
					if ( $searchset[$i]['topic_status'] == TOPIC_LOCKED )
					{
						$folder = $images['folder_locked'];
						$folder_new = $images['folder_locked_new'];
					}
					else if ( $searchset[$i]['topic_type'] == POST_ANNOUNCE )
					{
						$folder = $images['folder_announce'];
						$folder_new = $images['folder_announce_new'];
					}
					else if ( $searchset[$i]['topic_type'] == POST_STICKY )
					{
						$folder = $images['folder_sticky'];
						$folder_new = $images['folder_sticky_new'];
					}
					else
					{
						if ( $replies >= $board_config['hot_threshold'] )
						{
							$folder = $images['folder_hot'];
							$folder_new = $images['folder_hot_new'];
						}
						else
						{
							$folder = $images['folder'];
							$folder_new = $images['folder_new'];
						}
					}

					if ( $userdata['session_logged_in'] )
					{
						if ( $searchset[$i]['post_time'] > $userdata['user_lastvisit'] ) 
						{
							if ( !empty($tracking_topics) || !empty($tracking_forums) || isset($HTTP_COOKIE_VARS[$board_config['cookie_name'] . '_f_all']) )
							{

								$unread_topics = true;

								if ( !empty($tracking_topics[$topic_id]) )
								{
									if ( $tracking_topics[$topic_id] > $searchset[$i]['post_time'] )
									{
										$unread_topics = false;
									}
								}

								if ( !empty($tracking_forums[$forum_id]) )
								{
									if ( $tracking_forums[$forum_id] > $searchset[$i]['post_time'] )
									{
										$unread_topics = false;
									}
								}

								if ( isset($HTTP_COOKIE_VARS[$board_config['cookie_name'] . '_f_all']) )
								{
									if ( $HTTP_COOKIE_VARS[$board_config['cookie_name'] . '_f_all'] > $searchset[$i]['post_time'] )
									{
										$unread_topics = false;
									}
								}

								if ( $unread_topics )
								{
									$folder_image = $folder_new;
									$folder_alt = $lang['New_posts'];

									$newest_post_img = '<a href="' . append_sid("viewtopic.$phpEx?" . POST_TOPIC_URL . "=$topic_id&amp;view=newest") . '"><img src="' . $images['icon_newest_reply'] . '" alt="' . $lang['View_newest_post'] . '" title="' . $lang['View_newest_post'] . '" border="0" /></a> ';
								}
								else
								{
									$folder_alt = ( $searchset[$i]['topic_status'] == TOPIC_LOCKED ) ? $lang['Topic_locked'] : $lang['No_new_posts'];

									$folder_image = $folder;
									$folder_alt = $folder_alt;
									$newest_post_img = '';
								}

							}
							else if ( $searchset[$i]['post_time'] > $userdata['user_lastvisit'] ) 
							{
								$folder_image = $folder_new;
								$folder_alt = $lang['New_posts'];

								$newest_post_img = '<a href="' . append_sid("viewtopic.$phpEx?" . POST_TOPIC_URL . "=$topic_id&amp;view=newest") . '"><img src="' . $images['icon_newest_reply'] . '" alt="' . $lang['View_newest_post'] . '" title="' . $lang['View_newest_post'] . '" border="0" /></a> ';
							}
							else 
							{
								$folder_image = $folder;
								$folder_alt = ( $searchset[$i]['topic_status'] == TOPIC_LOCKED ) ? $lang['Topic_locked'] : $lang['No_new_posts'];
								$newest_post_img = '';
							}
						}
						else
						{
							$folder_image = $folder;
							$folder_alt = ( $searchset[$i]['topic_status'] == TOPIC_LOCKED ) ? $lang['Topic_locked'] : $lang['No_new_posts'];
							$newest_post_img = '';
						}
					}
					else
					{
						$folder_image = $folder;
						$folder_alt = ( $searchset[$i]['topic_status'] == TOPIC_LOCKED ) ? $lang['Topic_locked'] : $lang['No_new_posts'];
						$newest_post_img = '';
					}
				}


				$topic_author = ( $searchset[$i]['user_id'] != ANONYMOUS ) ? '<a href="' . append_sid("profile.$phpEx?mode=viewprofile&amp;" . POST_USERS_URL . '=' . $searchset[$i]['user_id']) . '">' : '';
				$topic_author .= ( $searchset[$i]['user_id'] != ANONYMOUS ) ? $searchset[$i]['username'] : ( ( $searchset[$i]['post_username'] != '' ) ? $searchset[$i]['post_username'] : $lang['Guest'] );

				$topic_author .= ( $searchset[$i]['user_id'] != ANONYMOUS ) ? '</a>' : '';

				$first_post_time = create_date($board_config['default_dateformat'], $searchset[$i]['topic_time'], $board_config['board_timezone']);

				$last_post_time = create_date($board_config['default_dateformat'], $searchset[$i]['post_time'], $board_config['board_timezone']);

				$last_post_author = ( $searchset[$i]['id2'] == ANONYMOUS ) ? ( ($searchset[$i]['post_username2'] != '' ) ? $searchset[$i]['post_username2'] . ' ' : $lang['Guest'] . ' ' ) : '<a href="' . append_sid("profile.$phpEx?mode=viewprofile&amp;" . POST_USERS_URL . '='  . $searchset[$i]['id2']) . '">' . $searchset[$i]['user2'] . '</a>';

				$last_post_url = '<a href="' . append_sid("viewtopic.$phpEx?"  . POST_POST_URL . '=' . $searchset[$i]['topic_last_post_id']) . '#' . $searchset[$i]['topic_last_post_id'] . '"><img src="' . $images['icon_latest_reply'] . '" alt="' . $lang['View_latest_post'] . '" title="' . $lang['View_latest_post'] . '" border="0" /></a>';

				$template->assign_block_vars('searchresults', array( 
					'FORUM_NAME' => $searchset[$i]['forum_name'],
					'FORUM_ID' => $forum_id,
					'TOPIC_ID' => $topic_id,
					'FOLDER' => $folder_image,
					'NEWEST_POST_IMG' => $newest_post_img, 
					'TOPIC_FOLDER_IMG' => $folder_image, 
					'GOTO_PAGE' => $goto_page,
					'REPLIES' => $replies,
					'TOPIC_TITLE' => $topic_title,
					'TOPIC_TYPE' => $topic_type,
					'VIEWS' => $views,
					'TOPIC_AUTHOR' => $topic_author, 
					'FIRST_POST_TIME' => $first_post_time, 
					'LAST_POST_TIME' => $last_post_time,
					'LAST_POST_AUTHOR' => $last_post_author,
					'LAST_POST_IMG' => $last_post_url,

					'L_TOPIC_FOLDER_ALT' => $folder_alt, 

					'U_VIEW_FORUM' => $forum_url, 
					'U_VIEW_TOPIC' => $topic_url)
				);
			}
		}

		$base_url = "search.$phpEx?search_id=$search_id";

		$template->assign_vars(array(
			'PAGINATION' => generate_pagination($base_url, $total_match_count, $per_page, $start),
			'PAGE_NUMBER' => sprintf($lang['Page_of'], ( floor( $start / $per_page ) + 1 ), ceil( $total_match_count / $per_page )), 

			'L_AUTHOR' => $lang['Author'],
			'L_MESSAGE' => $lang['Message'],
			'L_FORUM' => $lang['Forum'],
			'L_TOPICS' => $lang['Topics'],
			'L_REPLIES' => $lang['Replies'],
			'L_VIEWS' => $lang['Views'],
			'L_POSTS' => $lang['Posts'],
			'L_LASTPOST' => $lang['Last_Post'], 
			'L_POSTED' => $lang['Posted'], 
			'L_SUBJECT' => $lang['Subject'],

			'L_GOTO_PAGE' => $lang['Goto_page'])
		);

		$template->pparse('body');

		include($phpbb_root_path . 'includes/page_tail.'.$phpEx);
	}
	else
	{
		message_die(GENERAL_MESSAGE, $lang['No_search_match']);
	}
}

//
// Search forum
//
$sql = "SELECT c.cat_title, c.cat_id, f.forum_name, f.forum_id  
	FROM " . CATEGORIES_TABLE . " c, " . FORUMS_TABLE . " f
	WHERE f.cat_id = c.cat_id 
	ORDER BY c.cat_order, f.forum_order";
$result = $db->sql_query($sql);
if ( !$result )
{
	message_die(GENERAL_ERROR, 'Could not obtain forum_name/forum_id', '', __LINE__, __FILE__, $sql);
}

$is_auth_ary = auth(AUTH_READ, AUTH_LIST_ALL, $userdata);

$s_forums = '';
while( $row = $db->sql_fetchrow($result) )
{
	if ( $is_auth_ary[$row['forum_id']]['auth_read'] )
	{
		$s_forums .= '<option value="' . $row['forum_id'] . '">' . $row['forum_name'] . '</option>';
		if ( empty($list_cat[$row['cat_id']]) )
		{
			$list_cat[$row['cat_id']] = $row['cat_title'];
		}
	}
}

if ( $s_forums != '' )
{
	$s_forums = '<option value="-1">' . $lang['All_available'] . '</option>' . $s_forums;

	//
	// Category to search
	//
	$s_categories = '<option value="-1">' . $lang['All_available'] . '</option>';
	while( list($cat_id, $cat_title) = @each($list_cat))
	{
		$s_categories .= '<option value="' . $cat_id . '">' . $cat_title . '</option>';
	}
}
else
{
	message_die(GENERAL_MESSAGE, $lang['No_searchable_forums']);
}

//
// Number of chars returned
//
$s_characters = '<option value="-1">' . $lang['All_available'] . '</option>';
$s_characters .= '<option value="0">0</option>';
$s_characters .= '<option value="25">25</option>';
$s_characters .= '<option value="50">50</option>';

for($i = 100; $i < 1100 ; $i += 100)
{
	$selected = ( $i == 200 ) ? ' selected="selected"' : '';
	$s_characters .= '<option value="' . $i . '"' . $selected . '>' . $i . '</option>';
}

//
// Sorting
//
$s_sort_by = "";
for($i = 0; $i < count($sort_by_types); $i++)
{
	$s_sort_by .= '<option value="' . $i . '">' . $sort_by_types[$i] . '</option>';
}

//
// Search time
//
$previous_days = array(0, 1, 7, 14, 30, 90, 180, 364);
$previous_days_text = array($lang['All_Posts'], $lang['1_Day'], $lang['7_Days'], $lang['2_Weeks'], $lang['1_Month'], $lang['3_Months'], $lang['6_Months'], $lang['1_Year']);

$s_time = '';
for($i = 0; $i < count($previous_days); $i++)
{
	$selected = ( $topic_days == $previous_days[$i] ) ? ' selected="selected"' : '';
	$s_time .= '<option value="' . $previous_days[$i] . '"' . $selected . '>' . $previous_days_text[$i] . '</option>';
}

//
// Output the basic page
//
$page_title = $lang['Search'];
include($phpbb_root_path . 'includes/page_header.'.$phpEx);

$template->set_filenames(array(
	'body' => 'search_body.tpl')
);
make_jumpbox('viewforum.'.$phpEx);

$template->assign_vars(array(
	'L_SEARCH_QUERY' => $lang['Search_query'], 
	'L_SEARCH_OPTIONS' => $lang['Search_options'], 
	'L_SEARCH_KEYWORDS' => $lang['Search_keywords'], 
	'L_SEARCH_KEYWORDS_EXPLAIN' => $lang['Search_keywords_explain'], 
	'L_SEARCH_AUTHOR' => $lang['Search_author'],
	'L_SEARCH_AUTHOR_EXPLAIN' => $lang['Search_author_explain'], 
	'L_SEARCH_ANY_TERMS' => $lang['Search_for_any'],
	'L_SEARCH_ALL_TERMS' => $lang['Search_for_all'], 
	'L_SEARCH_MESSAGE_ONLY' => $lang['Search_msg_only'], 
	'L_SEARCH_MESSAGE_TITLE' => $lang['Search_title_msg'], 
	'L_CATEGORY' => $lang['Category'], 
	'L_RETURN_FIRST' => $lang['Return_first'],
	'L_CHARACTERS' => $lang['characters_posts'], 
	'L_SORT_BY' => $lang['Sort_by'],
	'L_SORT_ASCENDING' => $lang['Sort_Ascending'],
	'L_SORT_DESCENDING' => $lang['Sort_Descending'],
	'L_SEARCH_PREVIOUS' => $lang['Search_previous'], 
	'L_DISPLAY_RESULTS' => $lang['Display_results'], 
	'L_FORUM' => $lang['Forum'],
	'L_TOPICS' => $lang['Topics'],
	'L_POSTS' => $lang['Posts'],

	'S_SEARCH_ACTION' => append_sid("search.$phpEx?mode=results"),
	'S_CHARACTER_OPTIONS' => $s_characters,
	'S_FORUM_OPTIONS' => $s_forums, 
	'S_CATEGORY_OPTIONS' => $s_categories, 
	'S_TIME_OPTIONS' => $s_time, 
	'S_SORT_OPTIONS' => $s_sort_by,
	'S_HIDDEN_FIELDS' => '')
);

$template->pparse('body');

include($phpbb_root_path . 'includes/page_tail.'.$phpEx);

?>