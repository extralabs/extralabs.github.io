<?php


// phpBB 2.x auto-generated config file
// Do not change anything in this file!

$dbms = 'mysql4';

$dbhost = 'localhost';
$dbname = 'extralab_forum';
$dbuser = 'extralab_forum';
$dbpasswd = '3621940';

$table_prefix = 'phpbb2_';

define('PHPBB_INSTALLED', true);

?>